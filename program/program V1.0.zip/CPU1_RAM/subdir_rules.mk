################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Each subdirectory must supply rules for building sources it contributes
build-732792161: ../c2000.syscfg
	@echo 'Building file: "$<"'
	@echo 'Invoking: SysConfig'
	"D:/ti/ccs2020/ccs/utils/sysconfig_1.25.0/sysconfig_cli.bat" --script "C:/Users/12568/workspace_ccstheia/empty_sysconfig_48qfp/c2000.syscfg" -o "syscfg" -s "C:/TI/C2000Ware_6_00_01_00/.metadata/sdk.json" -d "F28002x" -p "48QFP" -r "F28002x_48QFP" --compiler ccs
	@echo 'Finished building: "$<"'
	@echo ' '

syscfg/board.c: build-732792161 ../c2000.syscfg
syscfg/board.h: build-732792161
syscfg/board.cmd.genlibs: build-732792161
syscfg/board.opt: build-732792161
syscfg/board.json: build-732792161
syscfg/pinmux.csv: build-732792161
syscfg/c2000ware_libraries.cmd.genlibs: build-732792161
syscfg/c2000ware_libraries.opt: build-732792161
syscfg/c2000ware_libraries.c: build-732792161
syscfg/c2000ware_libraries.h: build-732792161
syscfg/clocktree.h: build-732792161
syscfg: build-732792161

syscfg/%.obj: ./syscfg/%.c $(GEN_OPTS) | $(GEN_FILES) $(GEN_MISC_FILES)
	@echo 'Building file: "$<"'
	@echo 'Invoking: C2000 Compiler'
	"D:/ti/ccs2020/ccs/tools/compiler/ti-cgt-c2000_22.6.2.LTS/bin/cl2000" -v28 -ml -mt --float_support=fpu32 --idiv_support=idiv0 --tmu_support=tmu0 -Ooff --include_path="C:/Users/12568/workspace_ccstheia/empty_sysconfig_48qfp" --include_path="C:/Users/12568/workspace_ccstheia/empty_sysconfig_48qfp/device" --include_path="C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/" --include_path="D:/ti/ccs2020/ccs/tools/compiler/ti-cgt-c2000_22.6.2.LTS/include" --define=DEBUG --define=RAM --diag_suppress=10063 --diag_warning=225 --diag_wrap=off --display_error_number --gen_func_subsections=on --abi=eabi --preproc_with_compile --preproc_dependency="syscfg/$(basename $(<F)).d_raw" --include_path="C:/Users/12568/workspace_ccstheia/empty_sysconfig_48qfp/CPU1_RAM/syscfg" --obj_directory="syscfg" $(GEN_OPTS__FLAG) "$<"
	@echo 'Finished building: "$<"'
	@echo ' '

%.obj: ../%.c $(GEN_OPTS) | $(GEN_FILES) $(GEN_MISC_FILES)
	@echo 'Building file: "$<"'
	@echo 'Invoking: C2000 Compiler'
	"D:/ti/ccs2020/ccs/tools/compiler/ti-cgt-c2000_22.6.2.LTS/bin/cl2000" -v28 -ml -mt --float_support=fpu32 --idiv_support=idiv0 --tmu_support=tmu0 -Ooff --include_path="C:/Users/12568/workspace_ccstheia/empty_sysconfig_48qfp" --include_path="C:/Users/12568/workspace_ccstheia/empty_sysconfig_48qfp/device" --include_path="C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/" --include_path="D:/ti/ccs2020/ccs/tools/compiler/ti-cgt-c2000_22.6.2.LTS/include" --define=DEBUG --define=RAM --diag_suppress=10063 --diag_warning=225 --diag_wrap=off --display_error_number --gen_func_subsections=on --abi=eabi --preproc_with_compile --preproc_dependency="$(basename $(<F)).d_raw" --include_path="C:/Users/12568/workspace_ccstheia/empty_sysconfig_48qfp/CPU1_RAM/syscfg" $(GEN_OPTS__FLAG) "$<"
	@echo 'Finished building: "$<"'
	@echo ' '


