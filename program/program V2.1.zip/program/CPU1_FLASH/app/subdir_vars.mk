################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../app/bsp_tim.c \
../app/foc_core.c \
../app/main_isr.c \
../app/soft_spi_ma600.c 

C_DEPS += \
./app/bsp_tim.d \
./app/foc_core.d \
./app/main_isr.d \
./app/soft_spi_ma600.d 

OBJS += \
./app/bsp_tim.obj \
./app/foc_core.obj \
./app/main_isr.obj \
./app/soft_spi_ma600.obj 

OBJS__QUOTED += \
"app\bsp_tim.obj" \
"app\foc_core.obj" \
"app\main_isr.obj" \
"app\soft_spi_ma600.obj" 

C_DEPS__QUOTED += \
"app\bsp_tim.d" \
"app\foc_core.d" \
"app\main_isr.d" \
"app\soft_spi_ma600.d" 

C_SRCS__QUOTED += \
"../app/bsp_tim.c" \
"../app/foc_core.c" \
"../app/main_isr.c" \
"../app/soft_spi_ma600.c" 


