# FIXED

app/soft_spi_ma600.obj: ../app/soft_spi_ma600.c
app/soft_spi_ma600.obj: ../app/soft_spi_ma600.h
app/soft_spi_ma600.obj: C:/Users/12568/workspace_ccstheia/empty_sysconfig_48qfp/device/driverlib.h
app/soft_spi_ma600.obj: C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_memmap.h
app/soft_spi_ma600.obj: C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/adc.h
app/soft_spi_ma600.obj: D:/ti/ccs2020/ccs/tools/compiler/ti-cgt-c2000_22.6.2.LTS/include/stdbool.h
app/soft_spi_ma600.obj: D:/ti/ccs2020/ccs/tools/compiler/ti-cgt-c2000_22.6.2.LTS/include/_ti_config.h
app/soft_spi_ma600.obj: D:/ti/ccs2020/ccs/tools/compiler/ti-cgt-c2000_22.6.2.LTS/include/linkage.h
app/soft_spi_ma600.obj: D:/ti/ccs2020/ccs/tools/compiler/ti-cgt-c2000_22.6.2.LTS/include/stdint.h
app/soft_spi_ma600.obj: D:/ti/ccs2020/ccs/tools/compiler/ti-cgt-c2000_22.6.2.LTS/include/_stdint40.h
app/soft_spi_ma600.obj: D:/ti/ccs2020/ccs/tools/compiler/ti-cgt-c2000_22.6.2.LTS/include/sys/stdint.h
app/soft_spi_ma600.obj: D:/ti/ccs2020/ccs/tools/compiler/ti-cgt-c2000_22.6.2.LTS/include/sys/cdefs.h
app/soft_spi_ma600.obj: D:/ti/ccs2020/ccs/tools/compiler/ti-cgt-c2000_22.6.2.LTS/include/sys/_types.h
app/soft_spi_ma600.obj: D:/ti/ccs2020/ccs/tools/compiler/ti-cgt-c2000_22.6.2.LTS/include/machine/_types.h
app/soft_spi_ma600.obj: D:/ti/ccs2020/ccs/tools/compiler/ti-cgt-c2000_22.6.2.LTS/include/machine/_stdint.h
app/soft_spi_ma600.obj: D:/ti/ccs2020/ccs/tools/compiler/ti-cgt-c2000_22.6.2.LTS/include/sys/_stdint.h
app/soft_spi_ma600.obj: C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_adc.h
app/soft_spi_ma600.obj: C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_asysctl.h
app/soft_spi_ma600.obj: C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_types.h
app/soft_spi_ma600.obj: C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/cpu.h
app/soft_spi_ma600.obj: C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/debug.h
app/soft_spi_ma600.obj: C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/asysctl.h
app/soft_spi_ma600.obj: C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/bgcrc.h
app/soft_spi_ma600.obj: C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_bgcrc.h
app/soft_spi_ma600.obj: C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/can.h
app/soft_spi_ma600.obj: C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_can.h
app/soft_spi_ma600.obj: C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/sysctl.h
app/soft_spi_ma600.obj: C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_nmi.h
app/soft_spi_ma600.obj: C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_sysctl.h
app/soft_spi_ma600.obj: C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_otp.h
app/soft_spi_ma600.obj: C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/interrupt.h
app/soft_spi_ma600.obj: C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_ints.h
app/soft_spi_ma600.obj: C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_pie.h
app/soft_spi_ma600.obj: C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/clb.h
app/soft_spi_ma600.obj: C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_clb.h
app/soft_spi_ma600.obj: C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/cmpss.h
app/soft_spi_ma600.obj: C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_cmpss.h
app/soft_spi_ma600.obj: C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/cputimer.h
app/soft_spi_ma600.obj: C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_cputimer.h
app/soft_spi_ma600.obj: C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/dcc.h
app/soft_spi_ma600.obj: C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_dcc.h
app/soft_spi_ma600.obj: C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/dcsm.h
app/soft_spi_ma600.obj: C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_dcsm.h
app/soft_spi_ma600.obj: C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/dma.h
app/soft_spi_ma600.obj: C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_dma.h
app/soft_spi_ma600.obj: C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/ecap.h
app/soft_spi_ma600.obj: C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_ecap.h
app/soft_spi_ma600.obj: C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/epwm.h
app/soft_spi_ma600.obj: C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_epwm.h
app/soft_spi_ma600.obj: C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/eqep.h
app/soft_spi_ma600.obj: C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_eqep.h
app/soft_spi_ma600.obj: C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/erad.h
app/soft_spi_ma600.obj: C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_erad.h
app/soft_spi_ma600.obj: C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/flash.h
app/soft_spi_ma600.obj: C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_flash.h
app/soft_spi_ma600.obj: C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/fsi.h
app/soft_spi_ma600.obj: C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_fsi.h
app/soft_spi_ma600.obj: C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/hw_reg_inclusive_terminology.h
app/soft_spi_ma600.obj: C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/gpio.h
app/soft_spi_ma600.obj: C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_gpio.h
app/soft_spi_ma600.obj: C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_xint.h
app/soft_spi_ma600.obj: C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/xbar.h
app/soft_spi_ma600.obj: C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_clbxbar.h
app/soft_spi_ma600.obj: C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_epwmxbar.h
app/soft_spi_ma600.obj: C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_inputxbar.h
app/soft_spi_ma600.obj: C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_outputxbar.h
app/soft_spi_ma600.obj: C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_xbar.h
app/soft_spi_ma600.obj: C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/hrcap.h
app/soft_spi_ma600.obj: C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_hrcap.h
app/soft_spi_ma600.obj: C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/hrpwm.h
app/soft_spi_ma600.obj: C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_hrpwm.h
app/soft_spi_ma600.obj: C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/hrpwm.h
app/soft_spi_ma600.obj: C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/i2c.h
app/soft_spi_ma600.obj: C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_i2c.h
app/soft_spi_ma600.obj: C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/lin.h
app/soft_spi_ma600.obj: C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_lin.h
app/soft_spi_ma600.obj: C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/memcfg.h
app/soft_spi_ma600.obj: C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_memcfg.h
app/soft_spi_ma600.obj: C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/pin_map.h
app/soft_spi_ma600.obj: C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/pmbus.h
app/soft_spi_ma600.obj: C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_pmbus.h
app/soft_spi_ma600.obj: C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/pmbus_common.h
app/soft_spi_ma600.obj: C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/sci.h
app/soft_spi_ma600.obj: C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_sci.h
app/soft_spi_ma600.obj: C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/spi.h
app/soft_spi_ma600.obj: C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_spi.h
app/soft_spi_ma600.obj: C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/version.h
app/soft_spi_ma600.obj: C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/driver_inclusive_terminology_mapping.h
app/soft_spi_ma600.obj: C:/Users/12568/workspace_ccstheia/empty_sysconfig_48qfp/device/device.h
app/soft_spi_ma600.obj: D:/ti/ccs2020/ccs/tools/compiler/ti-cgt-c2000_22.6.2.LTS/include/stddef.h
app/soft_spi_ma600.obj: syscfg/board.h

../app/soft_spi_ma600.c:

../app/soft_spi_ma600.h:

C:/Users/12568/workspace_ccstheia/empty_sysconfig_48qfp/device/driverlib.h:

C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_memmap.h:

C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/adc.h:

D:/ti/ccs2020/ccs/tools/compiler/ti-cgt-c2000_22.6.2.LTS/include/stdbool.h:

D:/ti/ccs2020/ccs/tools/compiler/ti-cgt-c2000_22.6.2.LTS/include/_ti_config.h:

D:/ti/ccs2020/ccs/tools/compiler/ti-cgt-c2000_22.6.2.LTS/include/linkage.h:

D:/ti/ccs2020/ccs/tools/compiler/ti-cgt-c2000_22.6.2.LTS/include/stdint.h:

D:/ti/ccs2020/ccs/tools/compiler/ti-cgt-c2000_22.6.2.LTS/include/_stdint40.h:

D:/ti/ccs2020/ccs/tools/compiler/ti-cgt-c2000_22.6.2.LTS/include/sys/stdint.h:

D:/ti/ccs2020/ccs/tools/compiler/ti-cgt-c2000_22.6.2.LTS/include/sys/cdefs.h:

D:/ti/ccs2020/ccs/tools/compiler/ti-cgt-c2000_22.6.2.LTS/include/sys/_types.h:

D:/ti/ccs2020/ccs/tools/compiler/ti-cgt-c2000_22.6.2.LTS/include/machine/_types.h:

D:/ti/ccs2020/ccs/tools/compiler/ti-cgt-c2000_22.6.2.LTS/include/machine/_stdint.h:

D:/ti/ccs2020/ccs/tools/compiler/ti-cgt-c2000_22.6.2.LTS/include/sys/_stdint.h:

C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_adc.h:

C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_asysctl.h:

C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_types.h:

C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/cpu.h:

C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/debug.h:

C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/asysctl.h:

C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/bgcrc.h:

C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_bgcrc.h:

C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/can.h:

C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_can.h:

C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/sysctl.h:

C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_nmi.h:

C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_sysctl.h:

C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_otp.h:

C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/interrupt.h:

C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_ints.h:

C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_pie.h:

C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/clb.h:

C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_clb.h:

C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/cmpss.h:

C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_cmpss.h:

C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/cputimer.h:

C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_cputimer.h:

C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/dcc.h:

C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_dcc.h:

C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/dcsm.h:

C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_dcsm.h:

C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/dma.h:

C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_dma.h:

C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/ecap.h:

C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_ecap.h:

C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/epwm.h:

C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_epwm.h:

C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/eqep.h:

C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_eqep.h:

C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/erad.h:

C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_erad.h:

C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/flash.h:

C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_flash.h:

C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/fsi.h:

C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_fsi.h:

C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/hw_reg_inclusive_terminology.h:

C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/gpio.h:

C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_gpio.h:

C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_xint.h:

C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/xbar.h:

C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_clbxbar.h:

C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_epwmxbar.h:

C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_inputxbar.h:

C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_outputxbar.h:

C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_xbar.h:

C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/hrcap.h:

C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_hrcap.h:

C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/hrpwm.h:

C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_hrpwm.h:

C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/hrpwm.h:

C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/i2c.h:

C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_i2c.h:

C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/lin.h:

C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_lin.h:

C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/memcfg.h:

C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_memcfg.h:

C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/pin_map.h:

C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/pmbus.h:

C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_pmbus.h:

C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/pmbus_common.h:

C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/sci.h:

C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_sci.h:

C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/spi.h:

C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_spi.h:

C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/version.h:

C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/driver_inclusive_terminology_mapping.h:

C:/Users/12568/workspace_ccstheia/empty_sysconfig_48qfp/device/device.h:

D:/ti/ccs2020/ccs/tools/compiler/ti-cgt-c2000_22.6.2.LTS/include/stddef.h:

syscfg/board.h:

