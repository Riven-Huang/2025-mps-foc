# FIXED

app/main_isr.obj: ../app/main_isr.c
app/main_isr.obj: C:/Users/12568/workspace_ccstheia/empty_sysconfig_48qfp/device/driverlib.h
app/main_isr.obj: C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_memmap.h
app/main_isr.obj: C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/adc.h
app/main_isr.obj: D:/ti/ccs2020/ccs/tools/compiler/ti-cgt-c2000_22.6.2.LTS/include/stdbool.h
app/main_isr.obj: D:/ti/ccs2020/ccs/tools/compiler/ti-cgt-c2000_22.6.2.LTS/include/_ti_config.h
app/main_isr.obj: D:/ti/ccs2020/ccs/tools/compiler/ti-cgt-c2000_22.6.2.LTS/include/linkage.h
app/main_isr.obj: D:/ti/ccs2020/ccs/tools/compiler/ti-cgt-c2000_22.6.2.LTS/include/stdint.h
app/main_isr.obj: D:/ti/ccs2020/ccs/tools/compiler/ti-cgt-c2000_22.6.2.LTS/include/_stdint40.h
app/main_isr.obj: D:/ti/ccs2020/ccs/tools/compiler/ti-cgt-c2000_22.6.2.LTS/include/sys/stdint.h
app/main_isr.obj: D:/ti/ccs2020/ccs/tools/compiler/ti-cgt-c2000_22.6.2.LTS/include/sys/cdefs.h
app/main_isr.obj: D:/ti/ccs2020/ccs/tools/compiler/ti-cgt-c2000_22.6.2.LTS/include/sys/_types.h
app/main_isr.obj: D:/ti/ccs2020/ccs/tools/compiler/ti-cgt-c2000_22.6.2.LTS/include/machine/_types.h
app/main_isr.obj: D:/ti/ccs2020/ccs/tools/compiler/ti-cgt-c2000_22.6.2.LTS/include/machine/_stdint.h
app/main_isr.obj: D:/ti/ccs2020/ccs/tools/compiler/ti-cgt-c2000_22.6.2.LTS/include/sys/_stdint.h
app/main_isr.obj: C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_adc.h
app/main_isr.obj: C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_asysctl.h
app/main_isr.obj: C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_types.h
app/main_isr.obj: C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/cpu.h
app/main_isr.obj: C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/debug.h
app/main_isr.obj: C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/asysctl.h
app/main_isr.obj: C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/bgcrc.h
app/main_isr.obj: C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_bgcrc.h
app/main_isr.obj: C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/can.h
app/main_isr.obj: C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_can.h
app/main_isr.obj: C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/sysctl.h
app/main_isr.obj: C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_nmi.h
app/main_isr.obj: C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_sysctl.h
app/main_isr.obj: C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_otp.h
app/main_isr.obj: C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/interrupt.h
app/main_isr.obj: C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_ints.h
app/main_isr.obj: C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_pie.h
app/main_isr.obj: C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/clb.h
app/main_isr.obj: C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_clb.h
app/main_isr.obj: C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/cmpss.h
app/main_isr.obj: C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_cmpss.h
app/main_isr.obj: C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/cputimer.h
app/main_isr.obj: C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_cputimer.h
app/main_isr.obj: C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/dcc.h
app/main_isr.obj: C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_dcc.h
app/main_isr.obj: C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/dcsm.h
app/main_isr.obj: C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_dcsm.h
app/main_isr.obj: C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/dma.h
app/main_isr.obj: C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_dma.h
app/main_isr.obj: C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/ecap.h
app/main_isr.obj: C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_ecap.h
app/main_isr.obj: C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/epwm.h
app/main_isr.obj: C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_epwm.h
app/main_isr.obj: C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/eqep.h
app/main_isr.obj: C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_eqep.h
app/main_isr.obj: C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/erad.h
app/main_isr.obj: C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_erad.h
app/main_isr.obj: C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/flash.h
app/main_isr.obj: C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_flash.h
app/main_isr.obj: C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/fsi.h
app/main_isr.obj: C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_fsi.h
app/main_isr.obj: C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/hw_reg_inclusive_terminology.h
app/main_isr.obj: C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/gpio.h
app/main_isr.obj: C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_gpio.h
app/main_isr.obj: C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_xint.h
app/main_isr.obj: C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/xbar.h
app/main_isr.obj: C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_clbxbar.h
app/main_isr.obj: C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_epwmxbar.h
app/main_isr.obj: C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_inputxbar.h
app/main_isr.obj: C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_outputxbar.h
app/main_isr.obj: C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_xbar.h
app/main_isr.obj: C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/hrcap.h
app/main_isr.obj: C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_hrcap.h
app/main_isr.obj: C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/hrpwm.h
app/main_isr.obj: C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_hrpwm.h
app/main_isr.obj: C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/hrpwm.h
app/main_isr.obj: C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/i2c.h
app/main_isr.obj: C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_i2c.h
app/main_isr.obj: C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/lin.h
app/main_isr.obj: C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_lin.h
app/main_isr.obj: C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/memcfg.h
app/main_isr.obj: C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_memcfg.h
app/main_isr.obj: C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/pin_map.h
app/main_isr.obj: C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/pmbus.h
app/main_isr.obj: C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_pmbus.h
app/main_isr.obj: C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/pmbus_common.h
app/main_isr.obj: C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/sci.h
app/main_isr.obj: C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_sci.h
app/main_isr.obj: C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/spi.h
app/main_isr.obj: C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_spi.h
app/main_isr.obj: C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/version.h
app/main_isr.obj: C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/driver_inclusive_terminology_mapping.h
app/main_isr.obj: C:/Users/12568/workspace_ccstheia/empty_sysconfig_48qfp/device/device.h
app/main_isr.obj: D:/ti/ccs2020/ccs/tools/compiler/ti-cgt-c2000_22.6.2.LTS/include/stddef.h
app/main_isr.obj: ../app/foc_core.h
app/main_isr.obj: D:/ti/ccs2020/ccs/tools/compiler/ti-cgt-c2000_22.6.2.LTS/include/math.h
app/main_isr.obj: D:/ti/ccs2020/ccs/tools/compiler/ti-cgt-c2000_22.6.2.LTS/include/_defs.h
app/main_isr.obj: D:/ti/ccs2020/ccs/tools/compiler/ti-cgt-c2000_22.6.2.LTS/include/machine/_limits.h

../app/main_isr.c:

C:/Users/12568/workspace_ccstheia/empty_sysconfig_48qfp/device/driverlib.h:

C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_memmap.h:

C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/adc.h:

D:/ti/ccs2020/ccs/tools/compiler/ti-cgt-c2000_22.6.2.LTS/include/stdbool.h:

D:/ti/ccs2020/ccs/tools/compiler/ti-cgt-c2000_22.6.2.LTS/include/_ti_config.h:

D:/ti/ccs2020/ccs/tools/compiler/ti-cgt-c2000_22.6.2.LTS/include/linkage.h:

D:/ti/ccs2020/ccs/tools/compiler/ti-cgt-c2000_22.6.2.LTS/include/stdint.h:

D:/ti/ccs2020/ccs/tools/compiler/ti-cgt-c2000_22.6.2.LTS/include/_stdint40.h:

D:/ti/ccs2020/ccs/tools/compiler/ti-cgt-c2000_22.6.2.LTS/include/sys/stdint.h:

D:/ti/ccs2020/ccs/tools/compiler/ti-cgt-c2000_22.6.2.LTS/include/sys/cdefs.h:

D:/ti/ccs2020/ccs/tools/compiler/ti-cgt-c2000_22.6.2.LTS/include/sys/_types.h:

D:/ti/ccs2020/ccs/tools/compiler/ti-cgt-c2000_22.6.2.LTS/include/machine/_types.h:

D:/ti/ccs2020/ccs/tools/compiler/ti-cgt-c2000_22.6.2.LTS/include/machine/_stdint.h:

D:/ti/ccs2020/ccs/tools/compiler/ti-cgt-c2000_22.6.2.LTS/include/sys/_stdint.h:

C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_adc.h:

C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_asysctl.h:

C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_types.h:

C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/cpu.h:

C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/debug.h:

C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/asysctl.h:

C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/bgcrc.h:

C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_bgcrc.h:

C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/can.h:

C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_can.h:

C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/sysctl.h:

C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_nmi.h:

C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_sysctl.h:

C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_otp.h:

C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/interrupt.h:

C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_ints.h:

C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_pie.h:

C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/clb.h:

C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_clb.h:

C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/cmpss.h:

C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_cmpss.h:

C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/cputimer.h:

C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_cputimer.h:

C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/dcc.h:

C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_dcc.h:

C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/dcsm.h:

C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_dcsm.h:

C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/dma.h:

C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_dma.h:

C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/ecap.h:

C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_ecap.h:

C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/epwm.h:

C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_epwm.h:

C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/eqep.h:

C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_eqep.h:

C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/erad.h:

C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_erad.h:

C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/flash.h:

C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_flash.h:

C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/fsi.h:

C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_fsi.h:

C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/hw_reg_inclusive_terminology.h:

C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/gpio.h:

C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_gpio.h:

C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_xint.h:

C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/xbar.h:

C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_clbxbar.h:

C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_epwmxbar.h:

C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_inputxbar.h:

C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_outputxbar.h:

C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_xbar.h:

C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/hrcap.h:

C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_hrcap.h:

C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/hrpwm.h:

C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_hrpwm.h:

C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/hrpwm.h:

C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/i2c.h:

C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_i2c.h:

C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/lin.h:

C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_lin.h:

C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/memcfg.h:

C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_memcfg.h:

C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/pin_map.h:

C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/pmbus.h:

C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_pmbus.h:

C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/pmbus_common.h:

C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/sci.h:

C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_sci.h:

C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/spi.h:

C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_spi.h:

C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/version.h:

C:/TI/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/driver_inclusive_terminology_mapping.h:

C:/Users/12568/workspace_ccstheia/empty_sysconfig_48qfp/device/device.h:

D:/ti/ccs2020/ccs/tools/compiler/ti-cgt-c2000_22.6.2.LTS/include/stddef.h:

../app/foc_core.h:

D:/ti/ccs2020/ccs/tools/compiler/ti-cgt-c2000_22.6.2.LTS/include/math.h:

D:/ti/ccs2020/ccs/tools/compiler/ti-cgt-c2000_22.6.2.LTS/include/_defs.h:

D:/ti/ccs2020/ccs/tools/compiler/ti-cgt-c2000_22.6.2.LTS/include/machine/_limits.h:

