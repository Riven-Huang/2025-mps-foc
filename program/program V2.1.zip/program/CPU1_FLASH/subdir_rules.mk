################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Each subdirectory must supply rules for building sources it contributes
build-511106567: ../c2000.syscfg
	@echo 'Building file: "$<"'
	@echo 'Invoking: SysConfig'
	"D:/ti/CCS20.2.0.00012/ccs/utils/sysconfig_1.26.0/sysconfig_cli.bat" -s "D:/ti/c2000/C2000Ware_6_00_01_00/.metadata/sdk.json" -d "F28002x" -p "48QFP" -r "F28002x_48QFP" --script "C:/Users/banzang/workspace_ccstheia/test_test_test/c2000.syscfg" -o "syscfg" --compiler ccs
	@echo 'Finished building: "$<"'
	@echo ' '

syscfg/board.c: build-511106567 ../c2000.syscfg
syscfg/board.h: build-511106567
syscfg/board.cmd.genlibs: build-511106567
syscfg/board.opt: build-511106567
syscfg/board.json: build-511106567
syscfg/pinmux.csv: build-511106567
syscfg/epwm.dot: build-511106567
syscfg/adc.dot: build-511106567
syscfg/dcsm.asm: build-511106567
syscfg/dcsm.cmd: build-511106567
syscfg/c2000ware_libraries.cmd.genlibs: build-511106567
syscfg/c2000ware_libraries.opt: build-511106567
syscfg/c2000ware_libraries.c: build-511106567
syscfg/c2000ware_libraries.h: build-511106567
syscfg/clocktree.h: build-511106567
syscfg: build-511106567

syscfg/%.obj: ./syscfg/%.c $(GEN_OPTS) | $(GEN_FILES) $(GEN_MISC_FILES)
	@echo 'Building file: "$<"'
	@echo 'Invoking: C2000 Compiler'
	"D:/ti/CCS20.2.0.00012/ccs/tools/compiler/ti-cgt-c2000_22.6.2.LTS/bin/cl2000" -v28 -ml -mt --float_support=fpu32 --idiv_support=idiv0 --tmu_support=tmu0 -Ooff --include_path="C:/Users/banzang/workspace_ccstheia/test_test_test" --include_path="C:/Users/banzang/workspace_ccstheia/test_test_test/app" --include_path="C:/Users/banzang/workspace_ccstheia/test_test_test/device" --include_path="D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/" --include_path="D:/ti/CCS20.2.0.00012/ccs/tools/compiler/ti-cgt-c2000_22.6.2.LTS/include" --define=DEBUG --define=_FLASH --c99 --diag_suppress=10063 --diag_warning=225 --diag_wrap=off --display_error_number --gen_func_subsections=on --abi=eabi --preproc_with_compile --preproc_dependency="syscfg/$(basename $(<F)).d_raw" --include_path="C:/Users/banzang/workspace_ccstheia/test_test_test/CPU1_FLASH/syscfg" --obj_directory="syscfg" $(GEN_OPTS__FLAG) "$<"
	@echo 'Finished building: "$<"'
	@echo ' '

syscfg/%.obj: ./syscfg/%.asm $(GEN_OPTS) | $(GEN_FILES) $(GEN_MISC_FILES)
	@echo 'Building file: "$<"'
	@echo 'Invoking: C2000 Compiler'
	"D:/ti/CCS20.2.0.00012/ccs/tools/compiler/ti-cgt-c2000_22.6.2.LTS/bin/cl2000" -v28 -ml -mt --float_support=fpu32 --idiv_support=idiv0 --tmu_support=tmu0 -Ooff --include_path="C:/Users/banzang/workspace_ccstheia/test_test_test" --include_path="C:/Users/banzang/workspace_ccstheia/test_test_test/app" --include_path="C:/Users/banzang/workspace_ccstheia/test_test_test/device" --include_path="D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/" --include_path="D:/ti/CCS20.2.0.00012/ccs/tools/compiler/ti-cgt-c2000_22.6.2.LTS/include" --define=DEBUG --define=_FLASH --c99 --diag_suppress=10063 --diag_warning=225 --diag_wrap=off --display_error_number --gen_func_subsections=on --abi=eabi --preproc_with_compile --preproc_dependency="syscfg/$(basename $(<F)).d_raw" --include_path="C:/Users/banzang/workspace_ccstheia/test_test_test/CPU1_FLASH/syscfg" --obj_directory="syscfg" $(GEN_OPTS__FLAG) "$<"
	@echo 'Finished building: "$<"'
	@echo ' '

%.obj: ../%.c $(GEN_OPTS) | $(GEN_FILES) $(GEN_MISC_FILES)
	@echo 'Building file: "$<"'
	@echo 'Invoking: C2000 Compiler'
	"D:/ti/CCS20.2.0.00012/ccs/tools/compiler/ti-cgt-c2000_22.6.2.LTS/bin/cl2000" -v28 -ml -mt --float_support=fpu32 --idiv_support=idiv0 --tmu_support=tmu0 -Ooff --include_path="C:/Users/banzang/workspace_ccstheia/test_test_test" --include_path="C:/Users/banzang/workspace_ccstheia/test_test_test/app" --include_path="C:/Users/banzang/workspace_ccstheia/test_test_test/device" --include_path="D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/" --include_path="D:/ti/CCS20.2.0.00012/ccs/tools/compiler/ti-cgt-c2000_22.6.2.LTS/include" --define=DEBUG --define=_FLASH --c99 --diag_suppress=10063 --diag_warning=225 --diag_wrap=off --display_error_number --gen_func_subsections=on --abi=eabi --preproc_with_compile --preproc_dependency="$(basename $(<F)).d_raw" --include_path="C:/Users/banzang/workspace_ccstheia/test_test_test/CPU1_FLASH/syscfg" $(GEN_OPTS__FLAG) "$<"
	@echo 'Finished building: "$<"'
	@echo ' '


