
;----------------------------------------------------------------------
; Zone 1
;----------------------------------------------------------------------
     .sect "dcsm_otp_z1_linkpointer"
      .retain
      .long 0x1FFFFFFF
      .long 0xFFFFFFFF     ;Reserved
      .long 0x1FFFFFFF
      .long 0xFFFFFFFF     ;Reserved
      .long 0x1FFFFFFF
      .long 0xFFFFFFFF     ;Reserved
    
     .sect "dcsm_otp_z1_pswdlock"
      .retain
      .long 0xFB7FFFFF
      .long 0x7FFFFFFF     ;Reserved
      
     .sect "dcsm_otp_z1_crclock"
      .retain
      .long 0x4BFFFFFF
      .long 0x3FFFFFFF     ;Reserved
   
     .sect "dcsm_otp_z1_jtaglock"
      .retain
      .long 0x9FFFFFFF
      .long 0x0FFFFFFF     ;Reserved
     .sect "dcsm_otp_z1_gpreg"
      .retain
      .long 0x5AFF1820     ;Z1OTP_BOOTPIN_CONFIG
      .long 0x5Affffff     ;Z1OTP_GPREG2
     .sect "dcsm_otp_z1_bootctrl"
      .retain
      .long 0x00000003     ;Z1OTP_BOOTDEF_LOW
      .long 0xFFFFFFFF     ;Z1OTP_BOOTDEF_HIGH
      
     .sect "dcsm_zsel_z1"
      .retain
      .long 0x000000F0       ;Z1-EXEONLYRAM
      .long 0x0000FFFF      ;Z1-EXEONLYSECT
      .long 0x0000AA00          ;Z1-GRABRAM
      .long 0xAAAAAAAA         ;Z1-GRABSECT
      
      .long 0xFFFFFFFF
      .long 0x47FFFFFF
      .long 0xFFFFFFFF
      .long 0xFFFFFFFF


;----------------------------------------------------------------------

; For code security operation,after development has completed, prior to
; production, all other zone select block locations should be programmed
; to 0x0000 for maximum security.        
; If the first zone select block at offset 0x10 is used, the section 
; "dcsm_rsvd_z1" can be used to program these locations to 0x0000.
; This code is commented out for development.

;       .sect "dcsm_rsvd_z1"
;        .loop (1e0h)
;              .int 0x0000
;        .endloop


;----------------------------------------------------------------------
; Zone 2
;----------------------------------------------------------------------
     .sect "dcsm_otp_z2_linkpointer"
      .retain
      .long 0x1FFFFFFF
      .long 0xFFFFFFFF     ;Reserved
      .long 0x1FFFFFFF
      .long 0xFFFFFFFF     ;Reserved
      .long 0x1FFFFFFF
      .long 0xFFFFFFFF     ;Reserved

     .sect "dcsm_otp_z2_pswdlock"
      .retain
      .long 0xBF7FFFFF
      .long 0x77FFFFFF     ;Reserved
      
     .sect "dcsm_otp_z2_crclock"
      .retain
      .long 0x0FFFFFFF
      .long 0x37FFFFFF     ;Reserved
     .sect "dcsm_otp_z2_jtaglock"
      .retain
      .long 0xDBFFFFFF
      .long 0x07FFFFFF     ;Reserved
            
;;     .sect "dcsm_otp_z2_gpreg"
;;      .retain
;;      .long 0x5AFF1820     ;Z2OTP_BOOTPIN_CONFIG
;;      .long 0x5Affffff     ;Z2OTP_GPREG2
;;     .sect "dcsm_otp_z2_bootctrl"
;;      .retain
;;      .long 0x00000000     ;Z2OTP_BOOTDEF_LOW
;;      .long 0xFFFFFFFF     ;Z2OTP_BOOTDEF_HIGH
      
     .sect "dcsm_zsel_z2"
      .retain
      .long 0x000000F0       ;z2-EXEONLYRAM
      .long 0x0000FFFF      ;z2-EXEONLYSECT
      .long 0x0000AA00          ;z2-GRABRAM
      .long 0xAAAAAAAA         ;z2-GRABSECT
      
      .long 0xFFFFFFFF
      .long 0xE3FFFFFF
      .long 0xFFFFFFFF
      .long 0xFFFFFFFF


;----------------------------------------------------------------------

; For code security operation,after development has completed, prior to
; production, all other zone select block locations should be programmed
; to 0x0000 for maximum security.        
; If the first zone select block at offset 0x10 is used, the section 
; "dcsm_rsvd_z2" can be used to program these locations to 0x0000.
; This code is commented out for development.

;       .sect "dcsm_rsvd_z2"
;        .loop (1e0h)
;              .int 0x0000
;        .endloop


;----------------------------------------------------------------------
; End of file
;----------------------------------------------------------------------

