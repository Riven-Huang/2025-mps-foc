/*
 * Copyright (c) 2020 Texas Instruments Incorporated - http://www.ti.com
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 */

#include "board.h"

//*****************************************************************************
//
// Board Configurations
// Initializes the rest of the modules. 
// Call this function in your application if you wish to do all module 
// initialization.
// If you wish to not use some of the initializations, instead of the 
// Board_init use the individual Module_inits
//
//*****************************************************************************
void Board_init()
{
	EALLOW;

	PinMux_init();
	SYNC_init();
	ASYSCTL_init();
	ADC_init();
	CPUTIMER_init();
	EPWM_init();
	GPIO_init();
	INTERRUPT_init();

	EDIS;
}

//*****************************************************************************
//
// PINMUX Configurations
//
//*****************************************************************************
void PinMux_init()
{
	//
	// PinMux for modules assigned to CPU1
	//
	
	//
	// ANALOG -> ANALOGPinMux Pinmux
	//
	// Analog PinMux for A10/C10
	GPIO_setPinConfig(GPIO_230_GPIO230);
	// AIO -> Analog mode selected
	GPIO_setAnalogMode(230, GPIO_ANALOG_ENABLED);
	// Analog PinMux for A11/C0
	GPIO_setPinConfig(GPIO_237_GPIO237);
	// AIO -> Analog mode selected
	GPIO_setAnalogMode(237, GPIO_ANALOG_ENABLED);
	// Analog PinMux for A15/C7
	GPIO_setPinConfig(GPIO_233_GPIO233);
	// AIO -> Analog mode selected
	GPIO_setAnalogMode(233, GPIO_ANALOG_ENABLED);
	// Analog PinMux for A5/C2
	GPIO_setPinConfig(GPIO_244_GPIO244);
	// AIO -> Analog mode selected
	GPIO_setAnalogMode(244, GPIO_ANALOG_ENABLED);
	//
	// EPWM1 -> PhaseA_EPMW1 Pinmux
	//
	GPIO_setPinConfig(PhaseA_EPMW1_EPWMA_PIN_CONFIG);
	GPIO_setPadConfig(PhaseA_EPMW1_EPWMA_GPIO, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(PhaseA_EPMW1_EPWMA_GPIO, GPIO_QUAL_SYNC);

	GPIO_setPinConfig(PhaseA_EPMW1_EPWMB_PIN_CONFIG);
	GPIO_setPadConfig(PhaseA_EPMW1_EPWMB_GPIO, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(PhaseA_EPMW1_EPWMB_GPIO, GPIO_QUAL_SYNC);

	//
	// EPWM2 -> PhaseB_EPMW2 Pinmux
	//
	GPIO_setPinConfig(PhaseB_EPMW2_EPWMA_PIN_CONFIG);
	GPIO_setPadConfig(PhaseB_EPMW2_EPWMA_GPIO, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(PhaseB_EPMW2_EPWMA_GPIO, GPIO_QUAL_SYNC);

	GPIO_setPinConfig(PhaseB_EPMW2_EPWMB_PIN_CONFIG);
	GPIO_setPadConfig(PhaseB_EPMW2_EPWMB_GPIO, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(PhaseB_EPMW2_EPWMB_GPIO, GPIO_QUAL_SYNC);

	//
	// EPWM3 -> PhaseC_EPMW3 Pinmux
	//
	GPIO_setPinConfig(PhaseC_EPMW3_EPWMA_PIN_CONFIG);
	GPIO_setPadConfig(PhaseC_EPMW3_EPWMA_GPIO, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(PhaseC_EPMW3_EPWMA_GPIO, GPIO_QUAL_SYNC);

	GPIO_setPinConfig(PhaseC_EPMW3_EPWMB_PIN_CONFIG);
	GPIO_setPadConfig(PhaseC_EPMW3_EPWMB_GPIO, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(PhaseC_EPMW3_EPWMB_GPIO, GPIO_QUAL_SYNC);

	// GPIO28 -> LED1 Pinmux
	GPIO_setPinConfig(GPIO_28_GPIO28);
	// GPIO29 -> LED2 Pinmux
	GPIO_setPinConfig(GPIO_29_GPIO29);
	// GPIO7 -> mp6539_nSLEEP Pinmux
	GPIO_setPinConfig(GPIO_7_GPIO7);
	// GPIO6 -> mp6539_nFAULT Pinmux
	GPIO_setPinConfig(GPIO_6_GPIO6);
	// GPIO16 -> SW_SPI_CS Pinmux
	GPIO_setPinConfig(GPIO_16_GPIO16);
	// GPIO32 -> SW_SPI_CLK Pinmux
	GPIO_setPinConfig(GPIO_32_GPIO32);
	// GPIO33 -> SW_SPI_MOSI Pinmux
	GPIO_setPinConfig(GPIO_33_GPIO33);
	// GPIO24 -> SW_SPI_MISO Pinmux
	GPIO_setPinConfig(GPIO_24_GPIO24);

}

//*****************************************************************************
//
// ADC Configurations
//
//*****************************************************************************
void ADC_init(){
	IA_IC_ADCA_init();
	IB_VIN_ADCC_init();
}

void IA_IC_ADCA_init(){
	//
	// ADC Initialization: Write ADC configurations and power up the ADC
	//
	// Set the analog voltage reference selection and ADC module's offset trims.
	// This function sets the analog voltage reference to internal (with the reference voltage of 1.65V or 2.5V) or external for ADC
	// which is same as ASysCtl APIs.
	//
	ADC_setVREF(IA_IC_ADCA_BASE, ADC_REFERENCE_EXTERNAL, ADC_REFERENCE_2_5V);
	//
	// Configures the analog-to-digital converter module prescaler.
	//
	ADC_setPrescaler(IA_IC_ADCA_BASE, ADC_CLK_DIV_2_0);
	//
	// Sets the timing of the end-of-conversion pulse
	//
	ADC_setInterruptPulseMode(IA_IC_ADCA_BASE, ADC_PULSE_END_OF_CONV);
	//
	// Powers up the analog-to-digital converter core.
	//
	ADC_enableConverter(IA_IC_ADCA_BASE);
	//
	// Delay for 1ms to allow ADC time to power up
	//
	DEVICE_DELAY_US(500);
	//
	// SOC Configuration: Setup ADC EPWM channel and trigger settings
	//
	// Disables SOC burst mode.
	//
	ADC_disableBurstMode(IA_IC_ADCA_BASE);
	//
	// Sets the priority mode of the SOCs.
	//
	ADC_setSOCPriority(IA_IC_ADCA_BASE, ADC_PRI_ALL_ROUND_ROBIN);
	//
	// Start of Conversion 0 Configuration
	//
	//
	// Configures a start-of-conversion (SOC) in the ADC and its interrupt SOC trigger.
	// 	  	SOC number		: 0
	//	  	Trigger			: ADC_TRIGGER_EPWM1_SOCA
	//	  	Channel			: ADC_CH_ADCIN11
	//	 	Sample Window	: 20 SYSCLK cycles
	//		Interrupt Trigger: ADC_INT_SOC_TRIGGER_NONE
	//
	ADC_setupSOC(IA_IC_ADCA_BASE, ADC_SOC_NUMBER0, ADC_TRIGGER_EPWM1_SOCA, ADC_CH_ADCIN11, 20U);
	ADC_setInterruptSOCTrigger(IA_IC_ADCA_BASE, ADC_SOC_NUMBER0, ADC_INT_SOC_TRIGGER_NONE);
	//
	// Start of Conversion 1 Configuration
	//
	//
	// Configures a start-of-conversion (SOC) in the ADC and its interrupt SOC trigger.
	// 	  	SOC number		: 1
	//	  	Trigger			: ADC_TRIGGER_EPWM1_SOCA
	//	  	Channel			: ADC_CH_ADCIN5
	//	 	Sample Window	: 20 SYSCLK cycles
	//		Interrupt Trigger: ADC_INT_SOC_TRIGGER_NONE
	//
	ADC_setupSOC(IA_IC_ADCA_BASE, ADC_SOC_NUMBER1, ADC_TRIGGER_EPWM1_SOCA, ADC_CH_ADCIN5, 20U);
	ADC_setInterruptSOCTrigger(IA_IC_ADCA_BASE, ADC_SOC_NUMBER1, ADC_INT_SOC_TRIGGER_NONE);
	//
	// ADC Interrupt 1 Configuration
	// 		Source	: ADC_SOC_NUMBER0
	// 		Interrupt Source: enabled
	// 		Continuous Mode	: disabled
	//
	//
	ADC_setInterruptSource(IA_IC_ADCA_BASE, ADC_INT_NUMBER1, ADC_SOC_NUMBER0);
	ADC_clearInterruptStatus(IA_IC_ADCA_BASE, ADC_INT_NUMBER1);
	ADC_disableContinuousMode(IA_IC_ADCA_BASE, ADC_INT_NUMBER1);
	ADC_enableInterrupt(IA_IC_ADCA_BASE, ADC_INT_NUMBER1);
}

void IB_VIN_ADCC_init(){
	//
	// ADC Initialization: Write ADC configurations and power up the ADC
	//
	// Set the analog voltage reference selection and ADC module's offset trims.
	// This function sets the analog voltage reference to internal (with the reference voltage of 1.65V or 2.5V) or external for ADC
	// which is same as ASysCtl APIs.
	//
	ADC_setVREF(IB_VIN_ADCC_BASE, ADC_REFERENCE_EXTERNAL, ADC_REFERENCE_2_5V);
	//
	// Configures the analog-to-digital converter module prescaler.
	//
	ADC_setPrescaler(IB_VIN_ADCC_BASE, ADC_CLK_DIV_2_0);
	//
	// Sets the timing of the end-of-conversion pulse
	//
	ADC_setInterruptPulseMode(IB_VIN_ADCC_BASE, ADC_PULSE_END_OF_ACQ_WIN);
	//
	// Sets the timing of early interrupt generation.
	//
	ADC_setInterruptCycleOffset(IB_VIN_ADCC_BASE, 0U);
	//
	// Powers up the analog-to-digital converter core.
	//
	ADC_enableConverter(IB_VIN_ADCC_BASE);
	//
	// Delay for 1ms to allow ADC time to power up
	//
	DEVICE_DELAY_US(500);
	//
	// SOC Configuration: Setup ADC EPWM channel and trigger settings
	//
	// Disables SOC burst mode.
	//
	ADC_disableBurstMode(IB_VIN_ADCC_BASE);
	//
	// Sets the priority mode of the SOCs.
	//
	ADC_setSOCPriority(IB_VIN_ADCC_BASE, ADC_PRI_ALL_ROUND_ROBIN);
	//
	// Start of Conversion 0 Configuration
	//
	//
	// Configures a start-of-conversion (SOC) in the ADC and its interrupt SOC trigger.
	// 	  	SOC number		: 0
	//	  	Trigger			: ADC_TRIGGER_EPWM1_SOCA
	//	  	Channel			: ADC_CH_ADCIN7
	//	 	Sample Window	: 20 SYSCLK cycles
	//		Interrupt Trigger: ADC_INT_SOC_TRIGGER_NONE
	//
	ADC_setupSOC(IB_VIN_ADCC_BASE, ADC_SOC_NUMBER0, ADC_TRIGGER_EPWM1_SOCA, ADC_CH_ADCIN7, 20U);
	ADC_setInterruptSOCTrigger(IB_VIN_ADCC_BASE, ADC_SOC_NUMBER0, ADC_INT_SOC_TRIGGER_NONE);
	//
	// Start of Conversion 1 Configuration
	//
	//
	// Configures a start-of-conversion (SOC) in the ADC and its interrupt SOC trigger.
	// 	  	SOC number		: 1
	//	  	Trigger			: ADC_TRIGGER_EPWM1_SOCA
	//	  	Channel			: ADC_CH_ADCIN10
	//	 	Sample Window	: 20 SYSCLK cycles
	//		Interrupt Trigger: ADC_INT_SOC_TRIGGER_NONE
	//
	ADC_setupSOC(IB_VIN_ADCC_BASE, ADC_SOC_NUMBER1, ADC_TRIGGER_EPWM1_SOCA, ADC_CH_ADCIN10, 20U);
	ADC_setInterruptSOCTrigger(IB_VIN_ADCC_BASE, ADC_SOC_NUMBER1, ADC_INT_SOC_TRIGGER_NONE);
}


//*****************************************************************************
//
// ASYSCTL Configurations
//
//*****************************************************************************
void ASYSCTL_init(){
	//
	// asysctl initialization
	//
	// Disables the temperature sensor output to the ADC.
	//
	ASysCtl_disableTemperatureSensor();
	//
	// Set the analog voltage reference selection to external.
	//
	ASysCtl_setAnalogReferenceExternal( ASYSCTL_VREFHIA | ASYSCTL_VREFHIC );
}

//*****************************************************************************
//
// CPUTIMER Configurations
//
//*****************************************************************************
void CPUTIMER_init(){
	FOC_CPUTIMER0_init();
	FOC_CPUTIMER1_init();
	FOC_CPUTIMER2_init();
}

void FOC_CPUTIMER0_init(){
	CPUTimer_setEmulationMode(FOC_CPUTIMER0_BASE, CPUTIMER_EMULATIONMODE_STOPAFTERNEXTDECREMENT);
	CPUTimer_setPreScaler(FOC_CPUTIMER0_BASE, 20U);
	CPUTimer_setPeriod(FOC_CPUTIMER0_BASE, 999U);
	CPUTimer_enableInterrupt(FOC_CPUTIMER0_BASE);
	CPUTimer_stopTimer(FOC_CPUTIMER0_BASE);

	CPUTimer_reloadTimerCounter(FOC_CPUTIMER0_BASE);
	CPUTimer_startTimer(FOC_CPUTIMER0_BASE);
}
void FOC_CPUTIMER1_init(){
	CPUTimer_setEmulationMode(FOC_CPUTIMER1_BASE, CPUTIMER_EMULATIONMODE_STOPAFTERNEXTDECREMENT);
	CPUTimer_setPreScaler(FOC_CPUTIMER1_BASE, 20U);
	CPUTimer_setPeriod(FOC_CPUTIMER1_BASE, 999U);
	CPUTimer_enableInterrupt(FOC_CPUTIMER1_BASE);
	CPUTimer_stopTimer(FOC_CPUTIMER1_BASE);

	CPUTimer_reloadTimerCounter(FOC_CPUTIMER1_BASE);
	CPUTimer_startTimer(FOC_CPUTIMER1_BASE);
}
void FOC_CPUTIMER2_init(){
	CPUTimer_setEmulationMode(FOC_CPUTIMER2_BASE, CPUTIMER_EMULATIONMODE_STOPAFTERNEXTDECREMENT);
	CPUTimer_selectClockSource(FOC_CPUTIMER2_BASE, CPUTIMER_CLOCK_SOURCE_SYS, CPUTIMER_CLOCK_PRESCALER_1);
	CPUTimer_setPreScaler(FOC_CPUTIMER2_BASE, 20U);
	CPUTimer_setPeriod(FOC_CPUTIMER2_BASE, 999U);
	CPUTimer_enableInterrupt(FOC_CPUTIMER2_BASE);
	CPUTimer_stopTimer(FOC_CPUTIMER2_BASE);

	CPUTimer_reloadTimerCounter(FOC_CPUTIMER2_BASE);
	CPUTimer_startTimer(FOC_CPUTIMER2_BASE);
}

//*****************************************************************************
//
// EPWM Configurations
//
//*****************************************************************************
void EPWM_init(){
    EPWM_setClockPrescaler(PhaseA_EPMW1_BASE, EPWM_CLOCK_DIVIDER_1, EPWM_HSCLOCK_DIVIDER_1);	
    EPWM_setTimeBasePeriod(PhaseA_EPMW1_BASE, 2500);	
    EPWM_setTimeBaseCounter(PhaseA_EPMW1_BASE, 0);	
    EPWM_setTimeBaseCounterMode(PhaseA_EPMW1_BASE, EPWM_COUNTER_MODE_UP_DOWN);	
    EPWM_disablePhaseShiftLoad(PhaseA_EPMW1_BASE);	
    EPWM_setPhaseShift(PhaseA_EPMW1_BASE, 0);	
    EPWM_enableSyncOutPulseSource(PhaseA_EPMW1_BASE, EPWM_SYNC_OUT_PULSE_ON_CNTR_ZERO);	
    EPWM_setCounterCompareValue(PhaseA_EPMW1_BASE, EPWM_COUNTER_COMPARE_A, 1);	
    EPWM_setCounterCompareShadowLoadMode(PhaseA_EPMW1_BASE, EPWM_COUNTER_COMPARE_A, EPWM_COMP_LOAD_ON_CNTR_ZERO);	
    EPWM_setCounterCompareValue(PhaseA_EPMW1_BASE, EPWM_COUNTER_COMPARE_B, 1);	
    EPWM_setCounterCompareShadowLoadMode(PhaseA_EPMW1_BASE, EPWM_COUNTER_COMPARE_B, EPWM_COMP_LOAD_ON_CNTR_ZERO);	
    EPWM_setActionQualifierShadowLoadMode(PhaseA_EPMW1_BASE, EPWM_ACTION_QUALIFIER_A, EPWM_AQ_LOAD_ON_CNTR_ZERO);	
    EPWM_setActionQualifierAction(PhaseA_EPMW1_BASE, EPWM_AQ_OUTPUT_A, EPWM_AQ_OUTPUT_NO_CHANGE, EPWM_AQ_OUTPUT_ON_TIMEBASE_ZERO);	
    EPWM_setActionQualifierAction(PhaseA_EPMW1_BASE, EPWM_AQ_OUTPUT_A, EPWM_AQ_OUTPUT_NO_CHANGE, EPWM_AQ_OUTPUT_ON_TIMEBASE_PERIOD);	
    EPWM_setActionQualifierAction(PhaseA_EPMW1_BASE, EPWM_AQ_OUTPUT_A, EPWM_AQ_OUTPUT_LOW, EPWM_AQ_OUTPUT_ON_TIMEBASE_UP_CMPA);	
    EPWM_setActionQualifierAction(PhaseA_EPMW1_BASE, EPWM_AQ_OUTPUT_A, EPWM_AQ_OUTPUT_HIGH, EPWM_AQ_OUTPUT_ON_TIMEBASE_DOWN_CMPA);	
    EPWM_setActionQualifierAction(PhaseA_EPMW1_BASE, EPWM_AQ_OUTPUT_A, EPWM_AQ_OUTPUT_NO_CHANGE, EPWM_AQ_OUTPUT_ON_TIMEBASE_UP_CMPB);	
    EPWM_setActionQualifierAction(PhaseA_EPMW1_BASE, EPWM_AQ_OUTPUT_A, EPWM_AQ_OUTPUT_NO_CHANGE, EPWM_AQ_OUTPUT_ON_TIMEBASE_DOWN_CMPB);	
    EPWM_setActionQualifierShadowLoadMode(PhaseA_EPMW1_BASE, EPWM_ACTION_QUALIFIER_B, EPWM_AQ_LOAD_ON_CNTR_ZERO);	
    EPWM_setActionQualifierAction(PhaseA_EPMW1_BASE, EPWM_AQ_OUTPUT_B, EPWM_AQ_OUTPUT_NO_CHANGE, EPWM_AQ_OUTPUT_ON_TIMEBASE_ZERO);	
    EPWM_setActionQualifierAction(PhaseA_EPMW1_BASE, EPWM_AQ_OUTPUT_B, EPWM_AQ_OUTPUT_NO_CHANGE, EPWM_AQ_OUTPUT_ON_TIMEBASE_PERIOD);	
    EPWM_setActionQualifierAction(PhaseA_EPMW1_BASE, EPWM_AQ_OUTPUT_B, EPWM_AQ_OUTPUT_NO_CHANGE, EPWM_AQ_OUTPUT_ON_TIMEBASE_UP_CMPA);	
    EPWM_setActionQualifierAction(PhaseA_EPMW1_BASE, EPWM_AQ_OUTPUT_B, EPWM_AQ_OUTPUT_NO_CHANGE, EPWM_AQ_OUTPUT_ON_TIMEBASE_DOWN_CMPA);	
    EPWM_setActionQualifierAction(PhaseA_EPMW1_BASE, EPWM_AQ_OUTPUT_B, EPWM_AQ_OUTPUT_NO_CHANGE, EPWM_AQ_OUTPUT_ON_TIMEBASE_UP_CMPB);	
    EPWM_setActionQualifierAction(PhaseA_EPMW1_BASE, EPWM_AQ_OUTPUT_B, EPWM_AQ_OUTPUT_NO_CHANGE, EPWM_AQ_OUTPUT_ON_TIMEBASE_DOWN_CMPB);	
    EPWM_setDeadBandDelayPolarity(PhaseA_EPMW1_BASE, EPWM_DB_FED, EPWM_DB_POLARITY_ACTIVE_LOW);	
    EPWM_setDeadBandDelayMode(PhaseA_EPMW1_BASE, EPWM_DB_RED, true);	
    EPWM_setRisingEdgeDelayCountShadowLoadMode(PhaseA_EPMW1_BASE, EPWM_RED_LOAD_ON_CNTR_ZERO);	
    EPWM_setRisingEdgeDelayCount(PhaseA_EPMW1_BASE, 100);	
    EPWM_setDeadBandDelayMode(PhaseA_EPMW1_BASE, EPWM_DB_FED, true);	
    EPWM_setFallingEdgeDelayCountShadowLoadMode(PhaseA_EPMW1_BASE, EPWM_FED_LOAD_ON_CNTR_ZERO);	
    EPWM_setFallingEdgeDelayCount(PhaseA_EPMW1_BASE, 100);	
    EPWM_setDeadBandOutputSwapMode(PhaseA_EPMW1_BASE, EPWM_DB_OUTPUT_A, true);	
    EPWM_setDeadBandOutputSwapMode(PhaseA_EPMW1_BASE, EPWM_DB_OUTPUT_B, true);	
    EPWM_enableADCTrigger(PhaseA_EPMW1_BASE, EPWM_SOC_A);	
    EPWM_setADCTriggerSource(PhaseA_EPMW1_BASE, EPWM_SOC_A, EPWM_SOC_TBCTR_ZERO);	
    EPWM_setADCTriggerEventPrescale(PhaseA_EPMW1_BASE, EPWM_SOC_A, 1);	
    EPWM_setClockPrescaler(PhaseB_EPMW2_BASE, EPWM_CLOCK_DIVIDER_1, EPWM_HSCLOCK_DIVIDER_1);	
    EPWM_setTimeBasePeriod(PhaseB_EPMW2_BASE, 2500);	
    EPWM_setTimeBaseCounter(PhaseB_EPMW2_BASE, 0);	
    EPWM_setTimeBaseCounterMode(PhaseB_EPMW2_BASE, EPWM_COUNTER_MODE_UP_DOWN);	
    EPWM_setCountModeAfterSync(PhaseB_EPMW2_BASE, EPWM_COUNT_MODE_UP_AFTER_SYNC);	
    EPWM_enablePhaseShiftLoad(PhaseB_EPMW2_BASE);	
    EPWM_setPhaseShift(PhaseB_EPMW2_BASE, 0);	
    EPWM_enableSyncOutPulseSource(PhaseB_EPMW2_BASE, EPWM_SYNC_OUT_PULSE_ON_CNTR_ZERO);	
    EPWM_setCounterCompareValue(PhaseB_EPMW2_BASE, EPWM_COUNTER_COMPARE_A, 1);	
    EPWM_setCounterCompareShadowLoadMode(PhaseB_EPMW2_BASE, EPWM_COUNTER_COMPARE_A, EPWM_COMP_LOAD_ON_CNTR_ZERO);	
    EPWM_setCounterCompareValue(PhaseB_EPMW2_BASE, EPWM_COUNTER_COMPARE_B, 1);	
    EPWM_setCounterCompareShadowLoadMode(PhaseB_EPMW2_BASE, EPWM_COUNTER_COMPARE_B, EPWM_COMP_LOAD_ON_CNTR_ZERO);	
    EPWM_setActionQualifierShadowLoadMode(PhaseB_EPMW2_BASE, EPWM_ACTION_QUALIFIER_A, EPWM_AQ_LOAD_ON_CNTR_ZERO);	
    EPWM_setActionQualifierAction(PhaseB_EPMW2_BASE, EPWM_AQ_OUTPUT_A, EPWM_AQ_OUTPUT_NO_CHANGE, EPWM_AQ_OUTPUT_ON_TIMEBASE_ZERO);	
    EPWM_setActionQualifierAction(PhaseB_EPMW2_BASE, EPWM_AQ_OUTPUT_A, EPWM_AQ_OUTPUT_NO_CHANGE, EPWM_AQ_OUTPUT_ON_TIMEBASE_PERIOD);	
    EPWM_setActionQualifierAction(PhaseB_EPMW2_BASE, EPWM_AQ_OUTPUT_A, EPWM_AQ_OUTPUT_LOW, EPWM_AQ_OUTPUT_ON_TIMEBASE_UP_CMPA);	
    EPWM_setActionQualifierAction(PhaseB_EPMW2_BASE, EPWM_AQ_OUTPUT_A, EPWM_AQ_OUTPUT_HIGH, EPWM_AQ_OUTPUT_ON_TIMEBASE_DOWN_CMPA);	
    EPWM_setActionQualifierAction(PhaseB_EPMW2_BASE, EPWM_AQ_OUTPUT_A, EPWM_AQ_OUTPUT_NO_CHANGE, EPWM_AQ_OUTPUT_ON_TIMEBASE_UP_CMPB);	
    EPWM_setActionQualifierAction(PhaseB_EPMW2_BASE, EPWM_AQ_OUTPUT_A, EPWM_AQ_OUTPUT_NO_CHANGE, EPWM_AQ_OUTPUT_ON_TIMEBASE_DOWN_CMPB);	
    EPWM_disableActionQualifierShadowLoadMode(PhaseB_EPMW2_BASE, EPWM_ACTION_QUALIFIER_B);	
    EPWM_setActionQualifierShadowLoadMode(PhaseB_EPMW2_BASE, EPWM_ACTION_QUALIFIER_B, EPWM_AQ_LOAD_ON_CNTR_ZERO);	
    EPWM_setActionQualifierAction(PhaseB_EPMW2_BASE, EPWM_AQ_OUTPUT_B, EPWM_AQ_OUTPUT_NO_CHANGE, EPWM_AQ_OUTPUT_ON_TIMEBASE_ZERO);	
    EPWM_setActionQualifierAction(PhaseB_EPMW2_BASE, EPWM_AQ_OUTPUT_B, EPWM_AQ_OUTPUT_NO_CHANGE, EPWM_AQ_OUTPUT_ON_TIMEBASE_PERIOD);	
    EPWM_setActionQualifierAction(PhaseB_EPMW2_BASE, EPWM_AQ_OUTPUT_B, EPWM_AQ_OUTPUT_NO_CHANGE, EPWM_AQ_OUTPUT_ON_TIMEBASE_UP_CMPA);	
    EPWM_setActionQualifierAction(PhaseB_EPMW2_BASE, EPWM_AQ_OUTPUT_B, EPWM_AQ_OUTPUT_NO_CHANGE, EPWM_AQ_OUTPUT_ON_TIMEBASE_DOWN_CMPA);	
    EPWM_setActionQualifierAction(PhaseB_EPMW2_BASE, EPWM_AQ_OUTPUT_B, EPWM_AQ_OUTPUT_NO_CHANGE, EPWM_AQ_OUTPUT_ON_TIMEBASE_UP_CMPB);	
    EPWM_setActionQualifierAction(PhaseB_EPMW2_BASE, EPWM_AQ_OUTPUT_B, EPWM_AQ_OUTPUT_NO_CHANGE, EPWM_AQ_OUTPUT_ON_TIMEBASE_DOWN_CMPB);	
    EPWM_setDeadBandDelayPolarity(PhaseB_EPMW2_BASE, EPWM_DB_FED, EPWM_DB_POLARITY_ACTIVE_LOW);	
    EPWM_setDeadBandDelayMode(PhaseB_EPMW2_BASE, EPWM_DB_RED, true);	
    EPWM_setRisingEdgeDelayCountShadowLoadMode(PhaseB_EPMW2_BASE, EPWM_RED_LOAD_ON_CNTR_ZERO);	
    EPWM_setRisingEdgeDelayCount(PhaseB_EPMW2_BASE, 100);	
    EPWM_setDeadBandDelayMode(PhaseB_EPMW2_BASE, EPWM_DB_FED, true);	
    EPWM_setFallingEdgeDelayCountShadowLoadMode(PhaseB_EPMW2_BASE, EPWM_FED_LOAD_ON_CNTR_ZERO);	
    EPWM_setFallingEdgeDelayCount(PhaseB_EPMW2_BASE, 100);	
    EPWM_setDeadBandOutputSwapMode(PhaseB_EPMW2_BASE, EPWM_DB_OUTPUT_A, true);	
    EPWM_setDeadBandOutputSwapMode(PhaseB_EPMW2_BASE, EPWM_DB_OUTPUT_B, true);	
    EPWM_setClockPrescaler(PhaseC_EPMW3_BASE, EPWM_CLOCK_DIVIDER_1, EPWM_HSCLOCK_DIVIDER_1);	
    EPWM_setTimeBasePeriod(PhaseC_EPMW3_BASE, 2500);	
    EPWM_setTimeBaseCounter(PhaseC_EPMW3_BASE, 0);	
    EPWM_setTimeBaseCounterMode(PhaseC_EPMW3_BASE, EPWM_COUNTER_MODE_UP_DOWN);	
    EPWM_setCountModeAfterSync(PhaseC_EPMW3_BASE, EPWM_COUNT_MODE_UP_AFTER_SYNC);	
    EPWM_enablePhaseShiftLoad(PhaseC_EPMW3_BASE);	
    EPWM_setPhaseShift(PhaseC_EPMW3_BASE, 0);	
    EPWM_setSyncInPulseSource(PhaseC_EPMW3_BASE, EPWM_SYNC_IN_PULSE_SRC_SYNCOUT_EPWM2);	
    EPWM_setCounterCompareValue(PhaseC_EPMW3_BASE, EPWM_COUNTER_COMPARE_A, 1);	
    EPWM_setCounterCompareShadowLoadMode(PhaseC_EPMW3_BASE, EPWM_COUNTER_COMPARE_A, EPWM_COMP_LOAD_ON_CNTR_ZERO);	
    EPWM_setCounterCompareValue(PhaseC_EPMW3_BASE, EPWM_COUNTER_COMPARE_B, 1);	
    EPWM_setCounterCompareShadowLoadMode(PhaseC_EPMW3_BASE, EPWM_COUNTER_COMPARE_B, EPWM_COMP_LOAD_ON_CNTR_ZERO);	
    EPWM_setActionQualifierShadowLoadMode(PhaseC_EPMW3_BASE, EPWM_ACTION_QUALIFIER_A, EPWM_AQ_LOAD_ON_CNTR_ZERO);	
    EPWM_setActionQualifierAction(PhaseC_EPMW3_BASE, EPWM_AQ_OUTPUT_A, EPWM_AQ_OUTPUT_NO_CHANGE, EPWM_AQ_OUTPUT_ON_TIMEBASE_ZERO);	
    EPWM_setActionQualifierAction(PhaseC_EPMW3_BASE, EPWM_AQ_OUTPUT_A, EPWM_AQ_OUTPUT_NO_CHANGE, EPWM_AQ_OUTPUT_ON_TIMEBASE_PERIOD);	
    EPWM_setActionQualifierAction(PhaseC_EPMW3_BASE, EPWM_AQ_OUTPUT_A, EPWM_AQ_OUTPUT_LOW, EPWM_AQ_OUTPUT_ON_TIMEBASE_UP_CMPA);	
    EPWM_setActionQualifierAction(PhaseC_EPMW3_BASE, EPWM_AQ_OUTPUT_A, EPWM_AQ_OUTPUT_HIGH, EPWM_AQ_OUTPUT_ON_TIMEBASE_DOWN_CMPA);	
    EPWM_setActionQualifierAction(PhaseC_EPMW3_BASE, EPWM_AQ_OUTPUT_A, EPWM_AQ_OUTPUT_NO_CHANGE, EPWM_AQ_OUTPUT_ON_TIMEBASE_UP_CMPB);	
    EPWM_setActionQualifierAction(PhaseC_EPMW3_BASE, EPWM_AQ_OUTPUT_A, EPWM_AQ_OUTPUT_NO_CHANGE, EPWM_AQ_OUTPUT_ON_TIMEBASE_DOWN_CMPB);	
    EPWM_disableActionQualifierShadowLoadMode(PhaseC_EPMW3_BASE, EPWM_ACTION_QUALIFIER_B);	
    EPWM_setActionQualifierShadowLoadMode(PhaseC_EPMW3_BASE, EPWM_ACTION_QUALIFIER_B, EPWM_AQ_LOAD_ON_CNTR_ZERO);	
    EPWM_setActionQualifierAction(PhaseC_EPMW3_BASE, EPWM_AQ_OUTPUT_B, EPWM_AQ_OUTPUT_NO_CHANGE, EPWM_AQ_OUTPUT_ON_TIMEBASE_ZERO);	
    EPWM_setActionQualifierAction(PhaseC_EPMW3_BASE, EPWM_AQ_OUTPUT_B, EPWM_AQ_OUTPUT_NO_CHANGE, EPWM_AQ_OUTPUT_ON_TIMEBASE_PERIOD);	
    EPWM_setActionQualifierAction(PhaseC_EPMW3_BASE, EPWM_AQ_OUTPUT_B, EPWM_AQ_OUTPUT_NO_CHANGE, EPWM_AQ_OUTPUT_ON_TIMEBASE_UP_CMPA);	
    EPWM_setActionQualifierAction(PhaseC_EPMW3_BASE, EPWM_AQ_OUTPUT_B, EPWM_AQ_OUTPUT_NO_CHANGE, EPWM_AQ_OUTPUT_ON_TIMEBASE_DOWN_CMPA);	
    EPWM_setActionQualifierAction(PhaseC_EPMW3_BASE, EPWM_AQ_OUTPUT_B, EPWM_AQ_OUTPUT_NO_CHANGE, EPWM_AQ_OUTPUT_ON_TIMEBASE_UP_CMPB);	
    EPWM_setActionQualifierAction(PhaseC_EPMW3_BASE, EPWM_AQ_OUTPUT_B, EPWM_AQ_OUTPUT_NO_CHANGE, EPWM_AQ_OUTPUT_ON_TIMEBASE_DOWN_CMPB);	
    EPWM_setDeadBandDelayPolarity(PhaseC_EPMW3_BASE, EPWM_DB_FED, EPWM_DB_POLARITY_ACTIVE_LOW);	
    EPWM_setDeadBandDelayMode(PhaseC_EPMW3_BASE, EPWM_DB_RED, true);	
    EPWM_setRisingEdgeDelayCountShadowLoadMode(PhaseC_EPMW3_BASE, EPWM_RED_LOAD_ON_CNTR_ZERO);	
    EPWM_setRisingEdgeDelayCount(PhaseC_EPMW3_BASE, 100);	
    EPWM_setDeadBandDelayMode(PhaseC_EPMW3_BASE, EPWM_DB_FED, true);	
    EPWM_setFallingEdgeDelayCountShadowLoadMode(PhaseC_EPMW3_BASE, EPWM_FED_LOAD_ON_CNTR_ZERO);	
    EPWM_setFallingEdgeDelayCount(PhaseC_EPMW3_BASE, 100);	
}

//*****************************************************************************
//
// GPIO Configurations
//
//*****************************************************************************
void GPIO_init(){
	LED1_init();
	LED2_init();
	mp6539_nSLEEP_init();
	mp6539_nFAULT_init();
	SW_SPI_CS_init();
	SW_SPI_CLK_init();
	SW_SPI_MOSI_init();
	SW_SPI_MISO_init();
}

void LED1_init(){
	GPIO_writePin(LED1, 1);
	GPIO_setPadConfig(LED1, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(LED1, GPIO_QUAL_SYNC);
	GPIO_setDirectionMode(LED1, GPIO_DIR_MODE_OUT);
}
void LED2_init(){
	GPIO_writePin(LED2, 1);
	GPIO_setPadConfig(LED2, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(LED2, GPIO_QUAL_SYNC);
	GPIO_setDirectionMode(LED2, GPIO_DIR_MODE_OUT);
}
void mp6539_nSLEEP_init(){
	GPIO_writePin(mp6539_nSLEEP, 0);
	GPIO_setPadConfig(mp6539_nSLEEP, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(mp6539_nSLEEP, GPIO_QUAL_SYNC);
	GPIO_setDirectionMode(mp6539_nSLEEP, GPIO_DIR_MODE_OUT);
}
void mp6539_nFAULT_init(){
	GPIO_setPadConfig(mp6539_nFAULT, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(mp6539_nFAULT, GPIO_QUAL_SYNC);
	GPIO_setDirectionMode(mp6539_nFAULT, GPIO_DIR_MODE_OUT);
}
void SW_SPI_CS_init(){
	GPIO_writePin(SW_SPI_CS, 1);
	GPIO_setPadConfig(SW_SPI_CS, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(SW_SPI_CS, GPIO_QUAL_SYNC);
	GPIO_setDirectionMode(SW_SPI_CS, GPIO_DIR_MODE_OUT);
}
void SW_SPI_CLK_init(){
	GPIO_writePin(SW_SPI_CLK, 1);
	GPIO_setPadConfig(SW_SPI_CLK, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(SW_SPI_CLK, GPIO_QUAL_SYNC);
	GPIO_setDirectionMode(SW_SPI_CLK, GPIO_DIR_MODE_OUT);
}
void SW_SPI_MOSI_init(){
	GPIO_writePin(SW_SPI_MOSI, 0);
	GPIO_setPadConfig(SW_SPI_MOSI, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(SW_SPI_MOSI, GPIO_QUAL_SYNC);
	GPIO_setDirectionMode(SW_SPI_MOSI, GPIO_DIR_MODE_OUT);
}
void SW_SPI_MISO_init(){
	GPIO_writePin(SW_SPI_MISO, 0);
	GPIO_setPadConfig(SW_SPI_MISO, GPIO_PIN_TYPE_STD | GPIO_PIN_TYPE_PULLUP);
	GPIO_setQualificationMode(SW_SPI_MISO, GPIO_QUAL_SYNC);
	GPIO_setDirectionMode(SW_SPI_MISO, GPIO_DIR_MODE_IN);
}

//*****************************************************************************
//
// INTERRUPT Configurations
//
//*****************************************************************************
void INTERRUPT_init(){
	
	// Interrupt Settings for INT_IA_IC_ADCA_1
	// ISR need to be defined for the registered interrupts
	Interrupt_register(INT_IA_IC_ADCA_1, &INT_IA_IC_ADCA_INT1_ISR);
	Interrupt_enable(INT_IA_IC_ADCA_1);
	
	// Interrupt Settings for INT_FOC_CPUTIMER0
	// ISR need to be defined for the registered interrupts
	Interrupt_register(INT_FOC_CPUTIMER0, &INT_FOC_CPUTIMER0_ISR);
	Interrupt_enable(INT_FOC_CPUTIMER0);
	
	// Interrupt Settings for INT_FOC_CPUTIMER1
	// ISR need to be defined for the registered interrupts
	Interrupt_register(INT_FOC_CPUTIMER1, &INT_FOC_CPUTIMER1_ISR);
	Interrupt_enable(INT_FOC_CPUTIMER1);
	
	// Interrupt Settings for INT_FOC_CPUTIMER2
	// ISR need to be defined for the registered interrupts
	Interrupt_register(INT_FOC_CPUTIMER2, &INT_FOC_CPUTIMER2_ISR);
	Interrupt_enable(INT_FOC_CPUTIMER2);
}
//*****************************************************************************
//
// SYNC Scheme Configurations
//
//*****************************************************************************
void SYNC_init(){
	SysCtl_setSyncOutputConfig(SYSCTL_SYNC_OUT_SRC_EPWM1SYNCOUT);
	//
	// SOCA
	//
	SysCtl_enableExtADCSOCSource(0);
	//
	// SOCB
	//
	SysCtl_enableExtADCSOCSource(0);
}
