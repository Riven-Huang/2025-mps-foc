/*
 * Copyright (c) 2020 Texas Instruments Incorporated - http://www.ti.com
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 */

#ifndef BOARD_H
#define BOARD_H

//*****************************************************************************
//
// If building with a C++ compiler, make all of the definitions in this header
// have a C binding.
//
//*****************************************************************************
#ifdef __cplusplus
extern "C"
{
#endif

//
// Included Files
//

#include "driverlib.h"
#include "device.h"

//*****************************************************************************
//
// PinMux Configurations
//
//*****************************************************************************

//
// ANALOG -> ANALOGPinMux Pinmux
//

//
// EPWM1 -> PhaseA_EPMW1 Pinmux
//
//
// EPWM1_A - GPIO Settings
//
#define GPIO_PIN_EPWM1_A 0
#define PhaseA_EPMW1_EPWMA_GPIO 0
#define PhaseA_EPMW1_EPWMA_PIN_CONFIG GPIO_0_EPWM1_A
//
// EPWM1_B - GPIO Settings
//
#define GPIO_PIN_EPWM1_B 1
#define PhaseA_EPMW1_EPWMB_GPIO 1
#define PhaseA_EPMW1_EPWMB_PIN_CONFIG GPIO_1_EPWM1_B

//
// EPWM2 -> PhaseB_EPMW2 Pinmux
//
//
// EPWM2_A - GPIO Settings
//
#define GPIO_PIN_EPWM2_A 2
#define PhaseB_EPMW2_EPWMA_GPIO 2
#define PhaseB_EPMW2_EPWMA_PIN_CONFIG GPIO_2_EPWM2_A
//
// EPWM2_B - GPIO Settings
//
#define GPIO_PIN_EPWM2_B 3
#define PhaseB_EPMW2_EPWMB_GPIO 3
#define PhaseB_EPMW2_EPWMB_PIN_CONFIG GPIO_3_EPWM2_B

//
// EPWM3 -> PhaseC_EPMW3 Pinmux
//
//
// EPWM3_A - GPIO Settings
//
#define GPIO_PIN_EPWM3_A 4
#define PhaseC_EPMW3_EPWMA_GPIO 4
#define PhaseC_EPMW3_EPWMA_PIN_CONFIG GPIO_4_EPWM3_A
//
// EPWM3_B - GPIO Settings
//
#define GPIO_PIN_EPWM3_B 5
#define PhaseC_EPMW3_EPWMB_GPIO 5
#define PhaseC_EPMW3_EPWMB_PIN_CONFIG GPIO_5_EPWM3_B
//
// GPIO28 - GPIO Settings
//
#define LED1_GPIO_PIN_CONFIG GPIO_28_GPIO28
//
// GPIO29 - GPIO Settings
//
#define LED2_GPIO_PIN_CONFIG GPIO_29_GPIO29
//
// GPIO7 - GPIO Settings
//
#define mp6539_nSLEEP_GPIO_PIN_CONFIG GPIO_7_GPIO7
//
// GPIO6 - GPIO Settings
//
#define mp6539_nFAULT_GPIO_PIN_CONFIG GPIO_6_GPIO6
//
// GPIO16 - GPIO Settings
//
#define SW_SPI_CS_GPIO_PIN_CONFIG GPIO_16_GPIO16
//
// GPIO32 - GPIO Settings
//
#define SW_SPI_CLK_GPIO_PIN_CONFIG GPIO_32_GPIO32
//
// GPIO33 - GPIO Settings
//
#define SW_SPI_MOSI_GPIO_PIN_CONFIG GPIO_33_GPIO33
//
// GPIO24 - GPIO Settings
//
#define SW_SPI_MISO_GPIO_PIN_CONFIG GPIO_24_GPIO24

//*****************************************************************************
//
// ADC Configurations
//
//*****************************************************************************
#define IA_IC_ADCA_BASE ADCA_BASE
#define IA_IC_ADCA_RESULT_BASE ADCARESULT_BASE
#define IA_IC_ADCA_SOC0 ADC_SOC_NUMBER0
#define IA_IC_ADCA_FORCE_SOC0 ADC_FORCE_SOC0
#define IA_IC_ADCA_SAMPLE_WINDOW_SOC0 200
#define IA_IC_ADCA_TRIGGER_SOURCE_SOC0 ADC_TRIGGER_EPWM1_SOCA
#define IA_IC_ADCA_CHANNEL_SOC0 ADC_CH_ADCIN11
#define IA_IC_ADCA_SOC1 ADC_SOC_NUMBER1
#define IA_IC_ADCA_FORCE_SOC1 ADC_FORCE_SOC1
#define IA_IC_ADCA_SAMPLE_WINDOW_SOC1 200
#define IA_IC_ADCA_TRIGGER_SOURCE_SOC1 ADC_TRIGGER_EPWM1_SOCA
#define IA_IC_ADCA_CHANNEL_SOC1 ADC_CH_ADCIN5
void IA_IC_ADCA_init();

#define IB_VIN_ADCC_BASE ADCC_BASE
#define IB_VIN_ADCC_RESULT_BASE ADCCRESULT_BASE
#define IB_VIN_ADCC_SOC0 ADC_SOC_NUMBER0
#define IB_VIN_ADCC_FORCE_SOC0 ADC_FORCE_SOC0
#define IB_VIN_ADCC_SAMPLE_WINDOW_SOC0 200
#define IB_VIN_ADCC_TRIGGER_SOURCE_SOC0 ADC_TRIGGER_EPWM1_SOCA
#define IB_VIN_ADCC_CHANNEL_SOC0 ADC_CH_ADCIN7
#define IB_VIN_ADCC_SOC1 ADC_SOC_NUMBER1
#define IB_VIN_ADCC_FORCE_SOC1 ADC_FORCE_SOC1
#define IB_VIN_ADCC_SAMPLE_WINDOW_SOC1 200
#define IB_VIN_ADCC_TRIGGER_SOURCE_SOC1 ADC_TRIGGER_EPWM1_SOCA
#define IB_VIN_ADCC_CHANNEL_SOC1 ADC_CH_ADCIN10
void IB_VIN_ADCC_init();


//*****************************************************************************
//
// ASYSCTL Configurations
//
//*****************************************************************************

//*****************************************************************************
//
// CPUTIMER Configurations
//
//*****************************************************************************
#define FOC_CPUTIMER0_BASE CPUTIMER0_BASE
void FOC_CPUTIMER0_init();
#define FOC_CPUTIMER1_BASE CPUTIMER1_BASE
void FOC_CPUTIMER1_init();
#define FOC_CPUTIMER2_BASE CPUTIMER2_BASE
void FOC_CPUTIMER2_init();

//*****************************************************************************
//
// EPWM Configurations
//
//*****************************************************************************
#define PhaseA_EPMW1_BASE EPWM1_BASE
#define PhaseA_EPMW1_TBPRD 2500
#define PhaseA_EPMW1_COUNTER_MODE EPWM_COUNTER_MODE_UP_DOWN
#define PhaseA_EPMW1_TBPHS 0
#define PhaseA_EPMW1_CMPA 1
#define PhaseA_EPMW1_CMPB 1
#define PhaseA_EPMW1_CMPC 0
#define PhaseA_EPMW1_CMPD 0
#define PhaseA_EPMW1_DBRED 100
#define PhaseA_EPMW1_DBFED 100
#define PhaseA_EPMW1_TZA_ACTION EPWM_TZ_ACTION_HIGH_Z
#define PhaseA_EPMW1_TZB_ACTION EPWM_TZ_ACTION_HIGH_Z
#define PhaseA_EPMW1_INTERRUPT_SOURCE EPWM_INT_TBCTR_DISABLED
#define PhaseB_EPMW2_BASE EPWM2_BASE
#define PhaseB_EPMW2_TBPRD 2500
#define PhaseB_EPMW2_COUNTER_MODE EPWM_COUNTER_MODE_UP_DOWN
#define PhaseB_EPMW2_TBPHS 0
#define PhaseB_EPMW2_CMPA 1
#define PhaseB_EPMW2_CMPB 1
#define PhaseB_EPMW2_CMPC 0
#define PhaseB_EPMW2_CMPD 0
#define PhaseB_EPMW2_DBRED 100
#define PhaseB_EPMW2_DBFED 100
#define PhaseB_EPMW2_TZA_ACTION EPWM_TZ_ACTION_HIGH_Z
#define PhaseB_EPMW2_TZB_ACTION EPWM_TZ_ACTION_HIGH_Z
#define PhaseB_EPMW2_INTERRUPT_SOURCE EPWM_INT_TBCTR_DISABLED
#define PhaseC_EPMW3_BASE EPWM3_BASE
#define PhaseC_EPMW3_TBPRD 2500
#define PhaseC_EPMW3_COUNTER_MODE EPWM_COUNTER_MODE_UP_DOWN
#define PhaseC_EPMW3_TBPHS 0
#define PhaseC_EPMW3_CMPA 1
#define PhaseC_EPMW3_CMPB 1
#define PhaseC_EPMW3_CMPC 0
#define PhaseC_EPMW3_CMPD 0
#define PhaseC_EPMW3_DBRED 100
#define PhaseC_EPMW3_DBFED 100
#define PhaseC_EPMW3_TZA_ACTION EPWM_TZ_ACTION_HIGH_Z
#define PhaseC_EPMW3_TZB_ACTION EPWM_TZ_ACTION_HIGH_Z
#define PhaseC_EPMW3_INTERRUPT_SOURCE EPWM_INT_TBCTR_DISABLED

//*****************************************************************************
//
// GPIO Configurations
//
//*****************************************************************************
#define LED1 28
void LED1_init();
#define LED2 29
void LED2_init();
#define mp6539_nSLEEP 7
void mp6539_nSLEEP_init();
#define mp6539_nFAULT 6
void mp6539_nFAULT_init();
#define SW_SPI_CS 16
void SW_SPI_CS_init();
#define SW_SPI_CLK 32
void SW_SPI_CLK_init();
#define SW_SPI_MOSI 33
void SW_SPI_MOSI_init();
#define SW_SPI_MISO 24
void SW_SPI_MISO_init();

//*****************************************************************************
//
// INTERRUPT Configurations
//
//*****************************************************************************

// Interrupt Settings for INT_IA_IC_ADCA_1
// ISR need to be defined for the registered interrupts
#define INT_IA_IC_ADCA_1 INT_ADCA1
#define INT_IA_IC_ADCA_1_INTERRUPT_ACK_GROUP INTERRUPT_ACK_GROUP1
extern __interrupt void INT_IA_IC_ADCA_INT1_ISR(void);

// Interrupt Settings for INT_FOC_CPUTIMER0
// ISR need to be defined for the registered interrupts
#define INT_FOC_CPUTIMER0 INT_TIMER0
#define INT_FOC_CPUTIMER0_INTERRUPT_ACK_GROUP INTERRUPT_ACK_GROUP1
extern __interrupt void INT_FOC_CPUTIMER0_ISR(void);

// Interrupt Settings for INT_FOC_CPUTIMER1
// ISR need to be defined for the registered interrupts
#define INT_FOC_CPUTIMER1 INT_TIMER1
extern __interrupt void INT_FOC_CPUTIMER1_ISR(void);

// Interrupt Settings for INT_FOC_CPUTIMER2
// ISR need to be defined for the registered interrupts
#define INT_FOC_CPUTIMER2 INT_TIMER2
extern __interrupt void INT_FOC_CPUTIMER2_ISR(void);

//*****************************************************************************
//
// SYNC Scheme Configurations
//
//*****************************************************************************

//*****************************************************************************
//
// Board Configurations
//
//*****************************************************************************
void	Board_init();
void	ADC_init();
void	ASYSCTL_init();
void	CPUTIMER_init();
void	EPWM_init();
void	GPIO_init();
void	INTERRUPT_init();
void	SYNC_init();
void	PinMux_init();

//*****************************************************************************
//
// Mark the end of the C bindings section for C++ compilers.
//
//*****************************************************************************
#ifdef __cplusplus
}
#endif

#endif  // end of BOARD_H definition
