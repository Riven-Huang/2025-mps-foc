# FIXED

foc_main.obj: ../foc_main.c
foc_main.obj: C:/Users/banzang/workspace_ccstheia/test_test_test/device/driverlib.h
foc_main.obj: D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_memmap.h
foc_main.obj: D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/adc.h
foc_main.obj: D:/ti/CCS20.2.0.00012/ccs/tools/compiler/ti-cgt-c2000_22.6.2.LTS/include/stdbool.h
foc_main.obj: D:/ti/CCS20.2.0.00012/ccs/tools/compiler/ti-cgt-c2000_22.6.2.LTS/include/_ti_config.h
foc_main.obj: D:/ti/CCS20.2.0.00012/ccs/tools/compiler/ti-cgt-c2000_22.6.2.LTS/include/linkage.h
foc_main.obj: D:/ti/CCS20.2.0.00012/ccs/tools/compiler/ti-cgt-c2000_22.6.2.LTS/include/stdint.h
foc_main.obj: D:/ti/CCS20.2.0.00012/ccs/tools/compiler/ti-cgt-c2000_22.6.2.LTS/include/_stdint40.h
foc_main.obj: D:/ti/CCS20.2.0.00012/ccs/tools/compiler/ti-cgt-c2000_22.6.2.LTS/include/sys/stdint.h
foc_main.obj: D:/ti/CCS20.2.0.00012/ccs/tools/compiler/ti-cgt-c2000_22.6.2.LTS/include/sys/cdefs.h
foc_main.obj: D:/ti/CCS20.2.0.00012/ccs/tools/compiler/ti-cgt-c2000_22.6.2.LTS/include/sys/_types.h
foc_main.obj: D:/ti/CCS20.2.0.00012/ccs/tools/compiler/ti-cgt-c2000_22.6.2.LTS/include/machine/_types.h
foc_main.obj: D:/ti/CCS20.2.0.00012/ccs/tools/compiler/ti-cgt-c2000_22.6.2.LTS/include/machine/_stdint.h
foc_main.obj: D:/ti/CCS20.2.0.00012/ccs/tools/compiler/ti-cgt-c2000_22.6.2.LTS/include/sys/_stdint.h
foc_main.obj: D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_adc.h
foc_main.obj: D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_asysctl.h
foc_main.obj: D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_types.h
foc_main.obj: D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/cpu.h
foc_main.obj: D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/debug.h
foc_main.obj: D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/asysctl.h
foc_main.obj: D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/bgcrc.h
foc_main.obj: D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_bgcrc.h
foc_main.obj: D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/can.h
foc_main.obj: D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_can.h
foc_main.obj: D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/sysctl.h
foc_main.obj: D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_nmi.h
foc_main.obj: D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_sysctl.h
foc_main.obj: D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_otp.h
foc_main.obj: D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/interrupt.h
foc_main.obj: D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_ints.h
foc_main.obj: D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_pie.h
foc_main.obj: D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/clb.h
foc_main.obj: D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_clb.h
foc_main.obj: D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/cmpss.h
foc_main.obj: D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_cmpss.h
foc_main.obj: D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/cputimer.h
foc_main.obj: D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_cputimer.h
foc_main.obj: D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/dcc.h
foc_main.obj: D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_dcc.h
foc_main.obj: D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/dcsm.h
foc_main.obj: D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_dcsm.h
foc_main.obj: D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/dma.h
foc_main.obj: D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_dma.h
foc_main.obj: D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/ecap.h
foc_main.obj: D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_ecap.h
foc_main.obj: D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/epwm.h
foc_main.obj: D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_epwm.h
foc_main.obj: D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/eqep.h
foc_main.obj: D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_eqep.h
foc_main.obj: D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/erad.h
foc_main.obj: D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_erad.h
foc_main.obj: D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/flash.h
foc_main.obj: D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_flash.h
foc_main.obj: D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/fsi.h
foc_main.obj: D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_fsi.h
foc_main.obj: D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/hw_reg_inclusive_terminology.h
foc_main.obj: D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/gpio.h
foc_main.obj: D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_gpio.h
foc_main.obj: D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_xint.h
foc_main.obj: D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/xbar.h
foc_main.obj: D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_clbxbar.h
foc_main.obj: D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_epwmxbar.h
foc_main.obj: D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_inputxbar.h
foc_main.obj: D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_outputxbar.h
foc_main.obj: D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_xbar.h
foc_main.obj: D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/hrcap.h
foc_main.obj: D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_hrcap.h
foc_main.obj: D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/hrpwm.h
foc_main.obj: D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_hrpwm.h
foc_main.obj: D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/hrpwm.h
foc_main.obj: D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/i2c.h
foc_main.obj: D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_i2c.h
foc_main.obj: D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/lin.h
foc_main.obj: D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_lin.h
foc_main.obj: D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/memcfg.h
foc_main.obj: D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_memcfg.h
foc_main.obj: D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/pin_map.h
foc_main.obj: D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/pmbus.h
foc_main.obj: D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_pmbus.h
foc_main.obj: D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/pmbus_common.h
foc_main.obj: D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/sci.h
foc_main.obj: D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_sci.h
foc_main.obj: D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/spi.h
foc_main.obj: D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_spi.h
foc_main.obj: D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/version.h
foc_main.obj: D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/driver_inclusive_terminology_mapping.h
foc_main.obj: C:/Users/banzang/workspace_ccstheia/test_test_test/device/device.h
foc_main.obj: D:/ti/CCS20.2.0.00012/ccs/tools/compiler/ti-cgt-c2000_22.6.2.LTS/include/stddef.h
foc_main.obj: syscfg/board.h
foc_main.obj: syscfg/c2000ware_libraries.h
foc_main.obj: C:/Users/banzang/workspace_ccstheia/test_test_test/app/foc_core.h
foc_main.obj: D:/ti/CCS20.2.0.00012/ccs/tools/compiler/ti-cgt-c2000_22.6.2.LTS/include/math.h
foc_main.obj: D:/ti/CCS20.2.0.00012/ccs/tools/compiler/ti-cgt-c2000_22.6.2.LTS/include/_defs.h
foc_main.obj: D:/ti/CCS20.2.0.00012/ccs/tools/compiler/ti-cgt-c2000_22.6.2.LTS/include/machine/_limits.h
foc_main.obj: C:/Users/banzang/workspace_ccstheia/test_test_test/app/soft_spi_ma600.h

../foc_main.c:

C:/Users/banzang/workspace_ccstheia/test_test_test/device/driverlib.h:

D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_memmap.h:

D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/adc.h:

D:/ti/CCS20.2.0.00012/ccs/tools/compiler/ti-cgt-c2000_22.6.2.LTS/include/stdbool.h:

D:/ti/CCS20.2.0.00012/ccs/tools/compiler/ti-cgt-c2000_22.6.2.LTS/include/_ti_config.h:

D:/ti/CCS20.2.0.00012/ccs/tools/compiler/ti-cgt-c2000_22.6.2.LTS/include/linkage.h:

D:/ti/CCS20.2.0.00012/ccs/tools/compiler/ti-cgt-c2000_22.6.2.LTS/include/stdint.h:

D:/ti/CCS20.2.0.00012/ccs/tools/compiler/ti-cgt-c2000_22.6.2.LTS/include/_stdint40.h:

D:/ti/CCS20.2.0.00012/ccs/tools/compiler/ti-cgt-c2000_22.6.2.LTS/include/sys/stdint.h:

D:/ti/CCS20.2.0.00012/ccs/tools/compiler/ti-cgt-c2000_22.6.2.LTS/include/sys/cdefs.h:

D:/ti/CCS20.2.0.00012/ccs/tools/compiler/ti-cgt-c2000_22.6.2.LTS/include/sys/_types.h:

D:/ti/CCS20.2.0.00012/ccs/tools/compiler/ti-cgt-c2000_22.6.2.LTS/include/machine/_types.h:

D:/ti/CCS20.2.0.00012/ccs/tools/compiler/ti-cgt-c2000_22.6.2.LTS/include/machine/_stdint.h:

D:/ti/CCS20.2.0.00012/ccs/tools/compiler/ti-cgt-c2000_22.6.2.LTS/include/sys/_stdint.h:

D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_adc.h:

D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_asysctl.h:

D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_types.h:

D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/cpu.h:

D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/debug.h:

D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/asysctl.h:

D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/bgcrc.h:

D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_bgcrc.h:

D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/can.h:

D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_can.h:

D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/sysctl.h:

D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_nmi.h:

D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_sysctl.h:

D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_otp.h:

D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/interrupt.h:

D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_ints.h:

D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_pie.h:

D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/clb.h:

D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_clb.h:

D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/cmpss.h:

D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_cmpss.h:

D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/cputimer.h:

D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_cputimer.h:

D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/dcc.h:

D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_dcc.h:

D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/dcsm.h:

D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_dcsm.h:

D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/dma.h:

D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_dma.h:

D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/ecap.h:

D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_ecap.h:

D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/epwm.h:

D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_epwm.h:

D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/eqep.h:

D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_eqep.h:

D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/erad.h:

D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_erad.h:

D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/flash.h:

D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_flash.h:

D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/fsi.h:

D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_fsi.h:

D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/hw_reg_inclusive_terminology.h:

D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/gpio.h:

D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_gpio.h:

D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_xint.h:

D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/xbar.h:

D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_clbxbar.h:

D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_epwmxbar.h:

D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_inputxbar.h:

D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_outputxbar.h:

D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_xbar.h:

D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/hrcap.h:

D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_hrcap.h:

D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/hrpwm.h:

D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_hrpwm.h:

D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/hrpwm.h:

D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/i2c.h:

D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_i2c.h:

D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/lin.h:

D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_lin.h:

D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/memcfg.h:

D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_memcfg.h:

D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/pin_map.h:

D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/pmbus.h:

D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_pmbus.h:

D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/pmbus_common.h:

D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/sci.h:

D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_sci.h:

D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/spi.h:

D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_spi.h:

D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/version.h:

D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/driver_inclusive_terminology_mapping.h:

C:/Users/banzang/workspace_ccstheia/test_test_test/device/device.h:

D:/ti/CCS20.2.0.00012/ccs/tools/compiler/ti-cgt-c2000_22.6.2.LTS/include/stddef.h:

syscfg/board.h:

syscfg/c2000ware_libraries.h:

C:/Users/banzang/workspace_ccstheia/test_test_test/app/foc_core.h:

D:/ti/CCS20.2.0.00012/ccs/tools/compiler/ti-cgt-c2000_22.6.2.LTS/include/math.h:

D:/ti/CCS20.2.0.00012/ccs/tools/compiler/ti-cgt-c2000_22.6.2.LTS/include/_defs.h:

D:/ti/CCS20.2.0.00012/ccs/tools/compiler/ti-cgt-c2000_22.6.2.LTS/include/machine/_limits.h:

C:/Users/banzang/workspace_ccstheia/test_test_test/app/soft_spi_ma600.h:

