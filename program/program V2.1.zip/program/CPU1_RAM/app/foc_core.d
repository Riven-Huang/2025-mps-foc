# FIXED

app/foc_core.obj: ../app/foc_core.c
app/foc_core.obj: ../app/foc_core.h
app/foc_core.obj: D:/ti/CCS20.2.0.00012/ccs/tools/compiler/ti-cgt-c2000_22.6.2.LTS/include/math.h
app/foc_core.obj: D:/ti/CCS20.2.0.00012/ccs/tools/compiler/ti-cgt-c2000_22.6.2.LTS/include/_ti_config.h
app/foc_core.obj: D:/ti/CCS20.2.0.00012/ccs/tools/compiler/ti-cgt-c2000_22.6.2.LTS/include/linkage.h
app/foc_core.obj: D:/ti/CCS20.2.0.00012/ccs/tools/compiler/ti-cgt-c2000_22.6.2.LTS/include/_defs.h
app/foc_core.obj: D:/ti/CCS20.2.0.00012/ccs/tools/compiler/ti-cgt-c2000_22.6.2.LTS/include/sys/_types.h
app/foc_core.obj: D:/ti/CCS20.2.0.00012/ccs/tools/compiler/ti-cgt-c2000_22.6.2.LTS/include/sys/cdefs.h
app/foc_core.obj: D:/ti/CCS20.2.0.00012/ccs/tools/compiler/ti-cgt-c2000_22.6.2.LTS/include/machine/_types.h
app/foc_core.obj: D:/ti/CCS20.2.0.00012/ccs/tools/compiler/ti-cgt-c2000_22.6.2.LTS/include/machine/_limits.h
app/foc_core.obj: D:/ti/CCS20.2.0.00012/ccs/tools/compiler/ti-cgt-c2000_22.6.2.LTS/include/stdint.h
app/foc_core.obj: D:/ti/CCS20.2.0.00012/ccs/tools/compiler/ti-cgt-c2000_22.6.2.LTS/include/_stdint40.h
app/foc_core.obj: D:/ti/CCS20.2.0.00012/ccs/tools/compiler/ti-cgt-c2000_22.6.2.LTS/include/sys/stdint.h
app/foc_core.obj: D:/ti/CCS20.2.0.00012/ccs/tools/compiler/ti-cgt-c2000_22.6.2.LTS/include/machine/_stdint.h
app/foc_core.obj: D:/ti/CCS20.2.0.00012/ccs/tools/compiler/ti-cgt-c2000_22.6.2.LTS/include/sys/_stdint.h

../app/foc_core.c:

../app/foc_core.h:

D:/ti/CCS20.2.0.00012/ccs/tools/compiler/ti-cgt-c2000_22.6.2.LTS/include/math.h:

D:/ti/CCS20.2.0.00012/ccs/tools/compiler/ti-cgt-c2000_22.6.2.LTS/include/_ti_config.h:

D:/ti/CCS20.2.0.00012/ccs/tools/compiler/ti-cgt-c2000_22.6.2.LTS/include/linkage.h:

D:/ti/CCS20.2.0.00012/ccs/tools/compiler/ti-cgt-c2000_22.6.2.LTS/include/_defs.h:

D:/ti/CCS20.2.0.00012/ccs/tools/compiler/ti-cgt-c2000_22.6.2.LTS/include/sys/_types.h:

D:/ti/CCS20.2.0.00012/ccs/tools/compiler/ti-cgt-c2000_22.6.2.LTS/include/sys/cdefs.h:

D:/ti/CCS20.2.0.00012/ccs/tools/compiler/ti-cgt-c2000_22.6.2.LTS/include/machine/_types.h:

D:/ti/CCS20.2.0.00012/ccs/tools/compiler/ti-cgt-c2000_22.6.2.LTS/include/machine/_limits.h:

D:/ti/CCS20.2.0.00012/ccs/tools/compiler/ti-cgt-c2000_22.6.2.LTS/include/stdint.h:

D:/ti/CCS20.2.0.00012/ccs/tools/compiler/ti-cgt-c2000_22.6.2.LTS/include/_stdint40.h:

D:/ti/CCS20.2.0.00012/ccs/tools/compiler/ti-cgt-c2000_22.6.2.LTS/include/sys/stdint.h:

D:/ti/CCS20.2.0.00012/ccs/tools/compiler/ti-cgt-c2000_22.6.2.LTS/include/machine/_stdint.h:

D:/ti/CCS20.2.0.00012/ccs/tools/compiler/ti-cgt-c2000_22.6.2.LTS/include/sys/_stdint.h:

