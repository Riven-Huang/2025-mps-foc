# FIXED

app/soft_spi_ma600.obj: ../app/soft_spi_ma600.c
app/soft_spi_ma600.obj: ../app/soft_spi_ma600.h
app/soft_spi_ma600.obj: C:/Users/banzang/workspace_ccstheia/test_test_test/device/driverlib.h
app/soft_spi_ma600.obj: D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_memmap.h
app/soft_spi_ma600.obj: D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/adc.h
app/soft_spi_ma600.obj: D:/ti/CCS20.2.0.00012/ccs/tools/compiler/ti-cgt-c2000_22.6.2.LTS/include/stdbool.h
app/soft_spi_ma600.obj: D:/ti/CCS20.2.0.00012/ccs/tools/compiler/ti-cgt-c2000_22.6.2.LTS/include/_ti_config.h
app/soft_spi_ma600.obj: D:/ti/CCS20.2.0.00012/ccs/tools/compiler/ti-cgt-c2000_22.6.2.LTS/include/linkage.h
app/soft_spi_ma600.obj: D:/ti/CCS20.2.0.00012/ccs/tools/compiler/ti-cgt-c2000_22.6.2.LTS/include/stdint.h
app/soft_spi_ma600.obj: D:/ti/CCS20.2.0.00012/ccs/tools/compiler/ti-cgt-c2000_22.6.2.LTS/include/_stdint40.h
app/soft_spi_ma600.obj: D:/ti/CCS20.2.0.00012/ccs/tools/compiler/ti-cgt-c2000_22.6.2.LTS/include/sys/stdint.h
app/soft_spi_ma600.obj: D:/ti/CCS20.2.0.00012/ccs/tools/compiler/ti-cgt-c2000_22.6.2.LTS/include/sys/cdefs.h
app/soft_spi_ma600.obj: D:/ti/CCS20.2.0.00012/ccs/tools/compiler/ti-cgt-c2000_22.6.2.LTS/include/sys/_types.h
app/soft_spi_ma600.obj: D:/ti/CCS20.2.0.00012/ccs/tools/compiler/ti-cgt-c2000_22.6.2.LTS/include/machine/_types.h
app/soft_spi_ma600.obj: D:/ti/CCS20.2.0.00012/ccs/tools/compiler/ti-cgt-c2000_22.6.2.LTS/include/machine/_stdint.h
app/soft_spi_ma600.obj: D:/ti/CCS20.2.0.00012/ccs/tools/compiler/ti-cgt-c2000_22.6.2.LTS/include/sys/_stdint.h
app/soft_spi_ma600.obj: D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_adc.h
app/soft_spi_ma600.obj: D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_asysctl.h
app/soft_spi_ma600.obj: D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_types.h
app/soft_spi_ma600.obj: D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/cpu.h
app/soft_spi_ma600.obj: D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/debug.h
app/soft_spi_ma600.obj: D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/asysctl.h
app/soft_spi_ma600.obj: D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/bgcrc.h
app/soft_spi_ma600.obj: D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_bgcrc.h
app/soft_spi_ma600.obj: D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/can.h
app/soft_spi_ma600.obj: D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_can.h
app/soft_spi_ma600.obj: D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/sysctl.h
app/soft_spi_ma600.obj: D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_nmi.h
app/soft_spi_ma600.obj: D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_sysctl.h
app/soft_spi_ma600.obj: D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_otp.h
app/soft_spi_ma600.obj: D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/interrupt.h
app/soft_spi_ma600.obj: D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_ints.h
app/soft_spi_ma600.obj: D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_pie.h
app/soft_spi_ma600.obj: D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/clb.h
app/soft_spi_ma600.obj: D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_clb.h
app/soft_spi_ma600.obj: D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/cmpss.h
app/soft_spi_ma600.obj: D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_cmpss.h
app/soft_spi_ma600.obj: D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/cputimer.h
app/soft_spi_ma600.obj: D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_cputimer.h
app/soft_spi_ma600.obj: D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/dcc.h
app/soft_spi_ma600.obj: D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_dcc.h
app/soft_spi_ma600.obj: D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/dcsm.h
app/soft_spi_ma600.obj: D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_dcsm.h
app/soft_spi_ma600.obj: D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/dma.h
app/soft_spi_ma600.obj: D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_dma.h
app/soft_spi_ma600.obj: D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/ecap.h
app/soft_spi_ma600.obj: D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_ecap.h
app/soft_spi_ma600.obj: D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/epwm.h
app/soft_spi_ma600.obj: D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_epwm.h
app/soft_spi_ma600.obj: D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/eqep.h
app/soft_spi_ma600.obj: D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_eqep.h
app/soft_spi_ma600.obj: D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/erad.h
app/soft_spi_ma600.obj: D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_erad.h
app/soft_spi_ma600.obj: D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/flash.h
app/soft_spi_ma600.obj: D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_flash.h
app/soft_spi_ma600.obj: D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/fsi.h
app/soft_spi_ma600.obj: D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_fsi.h
app/soft_spi_ma600.obj: D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/hw_reg_inclusive_terminology.h
app/soft_spi_ma600.obj: D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/gpio.h
app/soft_spi_ma600.obj: D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_gpio.h
app/soft_spi_ma600.obj: D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_xint.h
app/soft_spi_ma600.obj: D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/xbar.h
app/soft_spi_ma600.obj: D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_clbxbar.h
app/soft_spi_ma600.obj: D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_epwmxbar.h
app/soft_spi_ma600.obj: D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_inputxbar.h
app/soft_spi_ma600.obj: D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_outputxbar.h
app/soft_spi_ma600.obj: D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_xbar.h
app/soft_spi_ma600.obj: D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/hrcap.h
app/soft_spi_ma600.obj: D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_hrcap.h
app/soft_spi_ma600.obj: D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/hrpwm.h
app/soft_spi_ma600.obj: D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_hrpwm.h
app/soft_spi_ma600.obj: D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/hrpwm.h
app/soft_spi_ma600.obj: D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/i2c.h
app/soft_spi_ma600.obj: D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_i2c.h
app/soft_spi_ma600.obj: D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/lin.h
app/soft_spi_ma600.obj: D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_lin.h
app/soft_spi_ma600.obj: D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/memcfg.h
app/soft_spi_ma600.obj: D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_memcfg.h
app/soft_spi_ma600.obj: D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/pin_map.h
app/soft_spi_ma600.obj: D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/pmbus.h
app/soft_spi_ma600.obj: D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_pmbus.h
app/soft_spi_ma600.obj: D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/pmbus_common.h
app/soft_spi_ma600.obj: D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/sci.h
app/soft_spi_ma600.obj: D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_sci.h
app/soft_spi_ma600.obj: D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/spi.h
app/soft_spi_ma600.obj: D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_spi.h
app/soft_spi_ma600.obj: D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/version.h
app/soft_spi_ma600.obj: D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/driver_inclusive_terminology_mapping.h
app/soft_spi_ma600.obj: C:/Users/banzang/workspace_ccstheia/test_test_test/device/device.h
app/soft_spi_ma600.obj: D:/ti/CCS20.2.0.00012/ccs/tools/compiler/ti-cgt-c2000_22.6.2.LTS/include/stddef.h
app/soft_spi_ma600.obj: syscfg/board.h

../app/soft_spi_ma600.c:

../app/soft_spi_ma600.h:

C:/Users/banzang/workspace_ccstheia/test_test_test/device/driverlib.h:

D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_memmap.h:

D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/adc.h:

D:/ti/CCS20.2.0.00012/ccs/tools/compiler/ti-cgt-c2000_22.6.2.LTS/include/stdbool.h:

D:/ti/CCS20.2.0.00012/ccs/tools/compiler/ti-cgt-c2000_22.6.2.LTS/include/_ti_config.h:

D:/ti/CCS20.2.0.00012/ccs/tools/compiler/ti-cgt-c2000_22.6.2.LTS/include/linkage.h:

D:/ti/CCS20.2.0.00012/ccs/tools/compiler/ti-cgt-c2000_22.6.2.LTS/include/stdint.h:

D:/ti/CCS20.2.0.00012/ccs/tools/compiler/ti-cgt-c2000_22.6.2.LTS/include/_stdint40.h:

D:/ti/CCS20.2.0.00012/ccs/tools/compiler/ti-cgt-c2000_22.6.2.LTS/include/sys/stdint.h:

D:/ti/CCS20.2.0.00012/ccs/tools/compiler/ti-cgt-c2000_22.6.2.LTS/include/sys/cdefs.h:

D:/ti/CCS20.2.0.00012/ccs/tools/compiler/ti-cgt-c2000_22.6.2.LTS/include/sys/_types.h:

D:/ti/CCS20.2.0.00012/ccs/tools/compiler/ti-cgt-c2000_22.6.2.LTS/include/machine/_types.h:

D:/ti/CCS20.2.0.00012/ccs/tools/compiler/ti-cgt-c2000_22.6.2.LTS/include/machine/_stdint.h:

D:/ti/CCS20.2.0.00012/ccs/tools/compiler/ti-cgt-c2000_22.6.2.LTS/include/sys/_stdint.h:

D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_adc.h:

D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_asysctl.h:

D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_types.h:

D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/cpu.h:

D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/debug.h:

D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/asysctl.h:

D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/bgcrc.h:

D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_bgcrc.h:

D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/can.h:

D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_can.h:

D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/sysctl.h:

D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_nmi.h:

D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_sysctl.h:

D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_otp.h:

D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/interrupt.h:

D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_ints.h:

D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_pie.h:

D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/clb.h:

D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_clb.h:

D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/cmpss.h:

D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_cmpss.h:

D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/cputimer.h:

D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_cputimer.h:

D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/dcc.h:

D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_dcc.h:

D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/dcsm.h:

D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_dcsm.h:

D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/dma.h:

D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_dma.h:

D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/ecap.h:

D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_ecap.h:

D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/epwm.h:

D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_epwm.h:

D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/eqep.h:

D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_eqep.h:

D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/erad.h:

D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_erad.h:

D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/flash.h:

D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_flash.h:

D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/fsi.h:

D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_fsi.h:

D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/hw_reg_inclusive_terminology.h:

D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/gpio.h:

D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_gpio.h:

D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_xint.h:

D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/xbar.h:

D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_clbxbar.h:

D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_epwmxbar.h:

D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_inputxbar.h:

D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_outputxbar.h:

D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_xbar.h:

D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/hrcap.h:

D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_hrcap.h:

D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/hrpwm.h:

D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_hrpwm.h:

D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/hrpwm.h:

D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/i2c.h:

D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_i2c.h:

D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/lin.h:

D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_lin.h:

D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/memcfg.h:

D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_memcfg.h:

D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/pin_map.h:

D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/pmbus.h:

D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_pmbus.h:

D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/pmbus_common.h:

D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/sci.h:

D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_sci.h:

D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/spi.h:

D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/inc/hw_spi.h:

D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/version.h:

D:/ti/c2000/C2000Ware_6_00_01_00/driverlib/f28002x/driverlib/driver_inclusive_terminology_mapping.h:

C:/Users/banzang/workspace_ccstheia/test_test_test/device/device.h:

D:/ti/CCS20.2.0.00012/ccs/tools/compiler/ti-cgt-c2000_22.6.2.LTS/include/stddef.h:

syscfg/board.h:

